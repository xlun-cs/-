#ifndef IMGUI_CUSTOMIZE_H
#define IMGUI_CUSTOMIZE_H

#include <string>
#include <vector>
#include "imgui.h"
#include "imgui_internal.h"

namespace fidenBoard {
    enum flags {
        flags_default = 0,
        flags_noNumbers = 1,
        flags_noCaps = 2
    };

    class Size {
    public:
        int width, height;
        Size(int width = 800, int height = 800);
    };

    class InputText {
    private:
        std::string text;
    public:
        void setText(std::string val);
        std::string getText();
        std::string* getAddress();
    };

    class Properties {
    private:
        flags flag;
        Size size;
        void initSize(ImVec2 sizze);
    public:
        Properties(ImVec2 size, flags flag = flags_default);
        flags getFlags();
        void setFlags(flags flag);
    };

    class Lines {
    public:
        std::string lines[3];
        Lines();
        void toCaps(bool caps);
        int getSize();
    };

    namespace specialChars {
        class Canc {
        public:
            void add(float width=80, float height=80);
        };

        extern bool isCaps;

        class Caps {
        public:
            void add(float width=80, float height=80);
        };

        class Space {
        public:
            void add();
        };
    }

    class FidenBoard {
    private:
        Properties *properties;
        specialChars::Canc canc;
        specialChars::Space space;
        specialChars::Caps caps;
        void addKeyword(std::string carattere, float width, float height);
        void addKeywordSameLine(std::string str, int width=80, int height=80);
    public:
        FidenBoard(ImVec2 size, flags flag = flags_default);
        std::string getInputText();
        void setInputText(std::string val);
    };
}

struct ButtonAnimation {
    float currentY;
    float targetY;
    bool isAnimating;
};

namespace ImGui {
    // 自定义::(控件)小组件
	IMGUI_API bool          M_SwitchButton(const char* str_id, bool* v, const ImVec2& size = ImVec2(2.30f, 0.82f));
    IMGUI_API bool          ButtonTextColored(const ImVec4& col, const char* fmt, ...);
    IMGUI_API bool          M_shut(const char* text);
    IMGUI_API void          M_shut(const char* text, bool* close);
    IMGUI_API void          M_shut_G(const char* text, bool* close, const ImVec4& col);
    IMGUI_API void          CenteredVerticalRadioGroup(const char* label, int* selectedIndex, const char* options[], int numOptions, float width, float totalHeight, float buttonHeight, float smoothness);
    IMGUI_API void          RenderVerticalMenu(const std::vector<std::string>& menu_items, int& selected_index);

}

#endif //IMGUI_CUSTOMIZE_H
