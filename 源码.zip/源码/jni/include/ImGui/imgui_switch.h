//直接调用SwitchButton函数即可
//例子：SwitchButton("自瞄开关", &自瞄开关[0]);
//自定义switchbutton开关控件
//这里为分别传参两个
//第一个是文字 char类型
//第二个是状态 bool值控制状态负责 开 / 关
void SwitchButton(const char* str_id, bool* v)
{
    ImVec4* colors = ImGui::GetStyle().Colors;
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImDrawList* draw_list = ImGui::GetWindowDrawList();
    
    //控件大小相关 自己调
    float height = 55;
    float width = height * 2.2f;
    float radius = height * 0.50f;
    
    //创建button按钮 初始为不可见状态
    ImGui::InvisibleButton(str_id, ImVec2(width, height));
    //监测点击事件
    if (ImGui::IsItemClicked()) *v = !*v;
    ImGuiContext& gg = *GImGui;
    float ANIM_SPEED = 0.085f;
    if (gg.LastActiveId == gg.CurrentWindow->GetID(str_id))
    float t_anim = ImSaturate(gg.LastActiveIdTimer / ANIM_SPEED);
    if (ImGui::IsItemHovered())
    draw_list->AddRectFilled(p, ImVec2(p.x + width, p.y + height), ImGui::GetColorU32(*v ? colors[ImGuiCol_ButtonActive] : ImVec4(0.78f, 0.78f, 0.78f, 1.0f)), height * 0.5f);
    else
    draw_list->AddRectFilled(p, ImVec2(p.x + width, p.y + height), ImGui::GetColorU32(*v ? colors[ImGuiCol_Button] : ImVec4(0.85f, 0.85f, 0.85f, 1.0f)), height * 0.50f);
    draw_list->AddCircleFilled(ImVec2(p.x + radius + (*v ? 1 : 0) * (width - radius * 2.0f), p.y + radius+0.5f), radius - 5.f, IM_COL32(255, 255, 255, 255));
    //开关右边的文字
    ImGui::RenderText(ImVec2(p.x + width*1.25f,  p.y + radius - 18), str_id);
}