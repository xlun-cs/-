// #### by币子 ## TG:@bizinb #### //
/*声明:本源码仅供游戏开发者修复漏洞参考,禁上个人用于非法要途,一切与作者无关,请在24小时内删除!!!
更多破解源码见TG频道:@bizinb
教程详见:快手:币子至上
完全公益!!!禁止⭕💰!!!
               by币子*/

#ifndef 物资_H
#define 物资_H

using namespace std;

bool alike(const string& Gname, const string& ClassName) {
return (Gname.find(ClassName)!= string::npos);
}

// string 宝箱(const string& n) {
// if (alike(n, "Escape_SupplyBax_Lv1_C") || alike(n, "EscapeBoxHight_SupplyBox_Lv1_C"))
// return "1 级宝箱";
// if (alike(n, "Escape_SupplyBax_Lv2_C") || alike(n, "EscapeBoxHight_SupplyBox_Lv2_C"))
// return "2 级宝箱";
// if (alike(n, "Escape_SupplyBax_Lv3_C") || alike(n, "EscapeBoxHight_SupplyBox_Lv3_C"))
// return "3 级宝箱";
// if (alike(n, "Escape_SupplyBax_Lv4_C") || alike(n, "EscapeBoxHight_SupplyBox_Lv4_C"))
// return "4 级宝箱";
// if (alike(n, "Escape_SupplyBax_Lv5_C") || alike(n, "EscapeBoxHight_SupplyBox_Lv5_C"))
// return "5 级宝箱";
/*
if (alike(n, "BP_InnerSupplyBoxBase_C"))
return "已开启";*/
// return "";
// }
bool BOOS(char *gname, char **name) {
     //ALOGD("判断类名%s",ClassName);
    std::string str(gname);
    if (strstr(gname, "Pawn_Escape_RD_Grenade_C") != nullptr)
{
    *name = "巡卫长·玄铁";
    return true;
}
if (strstr(gname, "Pawn_Escape_RD_RoyalGuards_C") != nullptr)
{
    *name = "影卫·银星";
    return true;
}
if (strstr(gname, "Pawn_Escape_Boss_Robocop_C") != nullptr)
{
    *name = "V-34机械警";
    return true;
}
if (strstr(gname, "Pawn_Escape_BOSS_Claws_C") != nullptr)
{
    *name = "钢爪·安德烈";
    return true;
}
if (strstr(gname, "Pawn_Escape_RD_SupplyBoss_C") != nullptr)
{
    *name = "辎重使·墨守";
    return true;
}
/*
if (strstr(gname, "BPPawn_Escape_Raven_C") != nullptr)
{
    *name = "飞鸟";
    return true;
}
if (strstr(gname, "BPPawn_Escape_Rookie_C") != nullptr)
{
    *name = "新兵";
    return true;
}
if (strstr(gname, "BPPawn_Escape_Rookie_WZ_C") != nullptr)
{
    *name = "新兵";
    return true;
}
if (strstr(gname, "BPPawn_Escape_ZombieVenom_C") != nullptr)
{
    *name = "感染者";
    return true;
}
if (strstr(gname, "BPPawn_Escape_ZombieFat_C") != nullptr)
{
    *name = "肥仔";
    return true;
}
if (strstr(gname, "BPPawn_Escape_Wolf_C") != nullptr)
{
    *name = "变异狼";
    return true;
}
if (strstr(gname, "BPPawn_Escape_WereWolf_C") != nullptr)
{
    *name = "狼人";
    return true;
}
if (strstr(gname, "BPPawn_Escape_ZombieMelee_C") != nullptr)
{
    *name = "变异体";
    return true;
}
*/
if (strstr(gname, "BPPawn_Escape_BOSS_Freezing_C") != nullptr)
{
    *name = "冰焰";
    return true;
}
if (strstr(gname, "BPPawn_Escape_BOSS_Jason_C") != nullptr)
{
    *name = "狂火-维烈";
    return true;
}
    return false;
    }
bool 宝箱类(char* gname, ImColor* color)
{
        if (strstr(gname, "EscapeBoxHight_SupplyBox_Lv4_C") != 0 ||
        strstr(gname, "EscapeBoxHight_SupplyBox_Lv5_C") != 0 ||
        strstr(gname, "EscapeBoxHight_SupplyBox_Lv6_C") != 0 )
        {      
            // color = ImColor(255, 255, 255);  
            return true;	
        }
        return false;
}
char *GetHol(int Wuqi) {
  switch (Wuqi) {
//突击步枪
    case 101008:
      return "M762";
      break;
    case 1010081:
      return "M762破损";
      break;
    case 1010082:
      return "M762修复";
      break;
    case 1010083:
      return "M762完好";
      break;
    case 1010084:
      return "M762改进";
      break;
    case 1010085:
      return "M762精致";
      break;
    case 1010086:
      return "M762独眼";
      break;
    case 1010087:
      return "M762钢铁";
      break;

    case 101001:
      return "AKM";
      break;
    case 1010011:
      return "AKM破损";
      break;
    case 1010012:
      return "AKM修复";
      break;
    case 1010013:
      return "AKM完好";
      break;
    case 1010014:
      return "AKM改进";
      break;
    case 1010015:
      return "AKM精致";
      break;
    case 1010016:
      return "AKM独眼";
      break;
    case 1010017:
      return "AKM钢铁";
      break;

    case 101004:
      return "M416";
      break;
    case 1010041:
      return "M416破损";
      break;
    case 1010042:
      return "M416修复";
      break;
    case 1010043:
      return "M416完好";
      break;
    case 1010044:
      return "M416改进";
      break;
    case 1010045:
      return "M416精致";
      break;
    case 1010046:
      return "M416独眼";
      break;
    case 1010047:
      return "M416钢铁";
      break;

    case 101003:
      return "SCAR-L";
      break;
    case 1010031:
      return "SCAR-L破损";
      break;
    case 1010032:
      return "SCAR-L修复";
      break;
    case 1010033:
      return "SCAR-L完好";
      break;
    case 1010034:
      return "SCAR-L改进";
      break;
    case 1010035:
      return "SCAR-L精致";
      break;
    case 1010036:
      return "SCAR-L独眼";
      break;
    case 1010037:
      return "SCAR-L钢铁";
      break;

    case 101002:
      return "M16A4";
      break;
    case 1010021:
      return "M16A4破损";
      break;
    case 1010022:
      return "M16A4修复";
      break;
    case 1010023:
      return "M16A4完好";
      break;
    case 1010024:
      return "M16A4改进";
      break;
    case 1010025:
      return "M16A4精致";
      break;
    case 1010026:
      return "M16A4独眼";
      break;
    case 1010027:
      return "M16A4钢铁";
      break;

    case 101009:
      return "Mk47";
      break;
    case 1010091:
      return "Mk47破损";
      break;
    case 1010092:
      return "Mk47修复";
      break;
    case 1010093:
      return "Mk47完好";
      break;
    case 1010094:
      return "Mk47改进";
      break;
    case 1010095:
      return "Mk47精致";
      break;
    case 1010096:
      return "Mk47独眼";
      break;
    case 1010097:
      return "Mk47钢铁";
      break;

    case 101006:
      return "AUG";
      break;
    case 1010061:
      return "AUG破损";
      break;
    case 1010062:
      return "AUG修复";
      break;
    case 1010063:
      return "AUG完好";
      break;
    case 1010064:
      return "AUG改进";
      break;
    case 1010065:
      return "AUG精致";
      break;
    case 1010066:
      return "AUG独眼";
      break;
    case 1010067:
      return "AUG钢铁";
      break;

    case 101005:
      return "Groza";
      break;
    case 1010051:
      return "Groza破损";
      break;
    case 1010052:
      return "Groza修复";
      break;
    case 1010053:
      return "Groza完好";
      break;
    case 1010054:
      return "Groza改进";
      break;
    case 1010055:
      return "Groza精致";
      break;
    case 1010056:
      return "Groza独眼";
      break;
    case 1010057:
      return "Groza钢铁";
      break;

    case 101010:
      return "G36C";
      break;
    case 1010101:
      return "G36C破损";
      break;
    case 1010102:
      return "G36C修复";
      break;
    case 1010103:
      return "G36C完好";
      break;
    case 1010104:
      return "G36C改进";
      break;
    case 1010105:
      return "G36C精致";
      break;
    case 1010106:
      return "G36C独眼";
      break;
    case 1010107:
      return "G36C钢铁";
      break;

    case 101007:
      return "QBZ";
      break;
    case 1010071:
      return "QBZ破损";
      break;
    case 1010072:
      return "QBZ修复";
      break;
    case 1010073:
      return "QBZ完好";
      break;
    case 1010074:
      return "QBZ改进";
      break;
    case 1010075:
      return "QBZ精致";
      break;
    case 1010076:
      return "QBZ独眼";
      break;
    case 1010077:
      return "QBZ钢铁";
      break;

    case 101011:
      return "AC-VAL";
      break;
    case 1010111:
      return "AC-VAL破损";
      break;
    case 1010112:
      return "AC-VAL修复";
      break;
    case 1010113:
      return "AC-VAL完好";
      break;
    case 1010114:
      return "AC-VAL改进";
      break;
    case 1010115:
      return "AC-VAL精致";
      break;
    case 1010116:
      return "AC-VAL独眼";
      break;
    case 1010117:
      return "AC-VAL钢铁";
      break;

    case 101012:
      return "蜜獾突击步枪";
      break;
    case 1010121:
      return "蜜獾突击步枪破损";
      break;
    case 1010122:
      return "蜜獾突击步枪修复";
      break;
    case 1010123:
      return "蜜獾突击步枪完好";
      break;
    case 1010124:
      return "蜜獾突击步枪改进";
      break;
    case 1010125:
      return "蜜獾突击步枪精致";
      break;
    case 1010126:
      return "蜜獾突击步枪独眼";
      break;
    case 1010127:
      return "蜜獾突击步枪钢铁";
      break;
//连狙
    case 103009:
      return "SLR";
      break;
    case 1030091:
      return "SLR破损";
      break;
    case 1030092:
      return "SLR修复";
      break;
    case 1030093:
      return "SLR完好";
      break;
    case 1030094:
      return "SLR改进";
      break;
    case 1030095:
      return "SLR精致";
      break;
    case 1030096:
      return "SLR独眼";
      break;
    case 1030097:
      return "SLR钢铁";
      break;

    case 103005:
      return "VSS";
      break;
    case 1030051:
      return "VSS破损";
      break;
    case 1030052:
      return "VSS修复";
      break;
    case 1030053:
      return "VSS完好";
      break;
    case 1030054:
      return "VSS改进";
      break;
    case 1030055:
      return "VSS精致";
      break;
    case 1030056:
      return "VSS独眼";
      break;
    case 1030057:
      return "VSS钢铁";
      break;

    case 103006:
      return "Mini14";
      break;
    case 1030061:
      return "Mini14破损";
      break;
    case 1030062:
      return "Mini14修复";
      break;
    case 1030063:
      return "Mini14完好";
      break;
    case 1030064:
      return "Mini14改进";
      break;
    case 1030065:
      return "Mini14精致";
      break;
    case 1030066:
      return "Mini14独眼";
      break;
    case 1030067:
      return "Mini14钢铁";
      break;

    case 103010:
      return "QBU";
      break;
    case 1030101:
      return "QBU破损";
      break;
    case 1030102:
      return "QBU修复";
      break;
    case 1030103:
      return "QBU完好";
      break;
    case 1030104:
      return "QBU改进";
      break;
    case 1030105:
      return "QBU精致";
      break;
    case 1030106:
      return "QBU独眼";
      break;
    case 1030107:
      return "QBU钢铁";
      break;

    case 103004:
      return "SKS";
      break;
    case 1030041:
      return "SKS破损";
      break;
    case 1030042:
      return "SKS修复";
      break;
    case 1030043:
      return "SKS完好";
      break;
    case 1030044:
      return "SKS改进";
      break;
    case 1030045:
      return "SKS精致";
      break;
    case 1030046:
      return "SKS独眼";
      break;
    case 1030047:
      return "SKS钢铁";
      break;

    case 103007:
      return "MK14";
      break;
    case 1030071:
      return "MK14破损";
      break;
    case 1030072:
      return "MK14修复";
      break;
    case 1030073:
      return "MK14完好";
      break;
    case 1030074:
      return "MK14改进";
      break;
    case 1030075:
      return "MK14精致";
      break;
    case 1030076:
      return "MK14独眼";
      break;
    case 1030077:
      return "MK14钢铁";
      break;

    case 103014:
      return "MK20-H";
      break;
    case 1030141:
      return "MK20-H破损";
      break;
    case 1030142:
      return "MK20-H修复";
      break;
    case 1030143:
      return "MK20-H完好";
      break;
    case 1030144:
      return "MK20-H改进";
      break;
    case 1030145:
      return "MK20-H精致";
      break;
    case 1030146:
      return "MK20-H独眼";
      break;
    case 1030147:
      return "MK20-H钢铁";
      break;

    case 103013:
      return "M4117";
      break;
    case 1030131:
      return "M4117破损";
      break;
    case 1030132:
      return "M4117修复";
      break;
    case 1030133:
      return "M4117完好";
      break;
    case 1030134:
      return "M4117改进";
      break;
    case 1030135:
      return "M4117精致";
      break;
    case 1030136:
      return "M4117独眼";
      break;
    case 1030137:
      return "M4117钢铁";
      break;
//连狙
    case 103012:
      return "ARM";
      break;
    case 1030121:
      return "ARM破损";
      break;
    case 1030122:
      return "ARM修复";
      break;
    case 1030123:
      return "ARM完好";
      break;
    case 1030124:
      return "ARM改进";
      break;
    case 1030125:
      return "ARM精致";
      break;
    case 1030126:
      return "ARM独眼";
      break;
    case 1030127:
      return "ARM钢铁";
      break;

    case 103003:
      return "AWM";
      break;
    case 1030031:
      return "AWM破损";
      break;
    case 1030032:
      return "AWM修复";
      break;
    case 1030033:
      return "AWM完好";
      break;
    case 1030034:
      return "AWM改进";
      break;
    case 1030035:
      return "AWM精致";
      break;
    case 1030036:
      return "AWM独眼";
      break;
    case 1030037:
      return "AWM钢铁";
      break;

    case 103002:
      return "M24";
      break;
    case 1030021:
      return "M24破损";
      break;
    case 1030022:
      return "M24修复";
      break;
    case 1030023:
      return "M24完好";
      break;
    case 1030024:
      return "M24改进";
      break;
    case 1030025:
      return "M24精致";
      break;
    case 1030026:
      return "M24独眼";
      break;
    case 1030027:
      return "M24钢铁";
      break;

    case 103011:
      return "莫幸纳甘";
      break;
    case 1030111:
      return "莫幸纳甘破损";
      break;
    case 1030112:
      return "莫幸纳甘修复";
      break;
    case 1030113:
      return "莫幸纳甘完好";
      break;
    case 1030114:
      return "莫幸纳甘改进";
      break;
    case 1030115:
      return "莫幸纳甘精致";
      break;
    case 1030116:
      return "莫幸纳甘独眼";
      break;
    case 1030117:
      return "莫幸纳甘钢铁";
      break;

    case 103001:
      return "Kar98K";
      break;
    case 1030011:
      return "Kar98K破损";
      break;
    case 1030012:
      return "Kar98K修复";
      break;
    case 1030013:
      return "Kar98K完好";
      break;
    case 1030014:
      return "Kar98K改进";
      break;
    case 1030015:
      return "Kar98K精致";
      break;
    case 1030016:
      return "Kar98K独眼";
      break;
    case 1030017:
      return "Kar98K钢铁";
      break;

    case 103008:
      return "Win94";
      break;
    case 1030081:
      return "Win94破损";
      break;
    case 1030082:
      return "Win94修复";
      break;
    case 1030083:
      return "Win94完好";
      break;
    case 1030084:
      return "Win94改进";
      break;
    case 1030085:
      return "Win94精致";
      break;
    case 1030086:
      return "Win94独眼";
      break;
    case 1030087:
      return "Win94钢铁";
      break;
//机关枪
    case 105001:
      return "M249";
      break;
    case 1050011:
      return "M249破损";
      break;
    case 1050012:
      return "M249修复";
      break;
    case 1050013:
      return "M249完好";
      break;
    case 1050014:
      return "M249改进";
      break;
    case 1050015:
      return "M249精致";
      break;
    case 1050016:
      return "M249独眼";
      break;
    case 1050017:
      return "M249钢铁";
      break;

    case 105002:
      return "DP-28";
      break;
    case 1050021:
      return "DP-28破损";
      break;
    case 1050022:
      return "DP-28修复";
      break;
    case 1050023:
      return "DP-28完好";
      break;
    case 1050024:
      return "DP-28改进";
      break;
    case 1050025:
      return "DP-28精致";
      break;
    case 1050026:
      return "DP-28独眼";
      break;
    case 1050027:
      return "DP-28钢铁";
      break;

    case 105010:
      return "MG3";
      break;
    case 1050101:
      return "MG3破损";
      break;
    case 1050102:
      return "MG3修复";
      break;
    case 1050103:
      return "MG3完好";
      break;
    case 1050104:
      return "MG3改进";
      break;
    case 1050105:
      return "MG3精致";
      break;
    case 1050106:
      return "MG3独眼";
      break;
    case 1050107:
      return "MG3钢铁";
      break;

    case 107001:
      return "十字弩";
      break;
    case 1070011:
      return "十字弩破损";
      break;
    case 1070012:
      return "十字弩修复";
      break;
    case 1070013:
      return "十字弩完好";
      break;
    case 1070014:
      return "十字弩改进";
      break;
    case 1070015:
      return "十字弩精致";
      break;
    case 1070016:
      return "十字弩独眼";
      break;
    case 1070017:
      return "十字弩钢铁";
      break;

    case 107007:
      return "爆炸猎弓";
      break;
    case 1070071:
      return "爆炸猎弓破损";
      break;
    case 1070072:
      return "爆炸猎弓修复";
      break;
    case 1070073:
      return "爆炸猎弓完好";
      break;
    case 1070074:
      return "爆炸猎弓改进";
      break;
    case 1070075:
      return "爆炸猎弓精致";
      break;
    case 1070076:
      return "爆炸猎弓独眼";
      break;
    case 1070077:
      return "爆炸猎弓钢铁";
      break;
//冲锋枪
    case 102001:
      return "UZI";
      break;
    case 1020011:
      return "UZI破损";
      break;
    case 1020012:
      return "UZI修复";
      break;
    case 1020013:
      return "UZI完好";
      break;
    case 1020014:
      return "UZI改进";
      break;
    case 1020015:
      return "UZI精致";
      break;
    case 1020016:
      return "UZI独眼";
      break;
    case 1020017:
      return "UZI钢铁";
      break;

    case 102003:
      return "Vector";
      break;
    case 1020031:
      return "Vector破损";
      break;
    case 1020032:
      return "Vector修复";
      break;
    case 1020033:
      return "Vector完好";
      break;
    case 1020034:
      return "Vector改进";
      break;
    case 1020035:
      return "Vector精致";
      break;
    case 1020036:
      return "Vector独眼";
      break;
    case 1020037:
      return "Vector钢铁";
      break;
      
    case 100103:
      return "PP-19";
      break;
    case 1001031:
      return "PP-19破损";
      break;
    case 1001032:
      return "PP-19修复";
      break;
    case 1001033:
      return "PP-19完好";
      break;
    case 1001034:
      return "PP-19改进";
      break;
    case 1001035:
      return "PP-19精致";
      break;
    case 1001036:
      return "PP-19独眼";
      break;
    case 1001037:
      return "PP-19钢铁";
      break;

    case 102007:
      return "MP5K";
      break;
    case 1020071:
      return "MP5K破损";
      break;
    case 1020072:
      return "MP5K修复";
      break;
    case 1020073:
      return "MP5K完好";
      break;
    case 1020074:
      return "MP5K改进";
      break;
    case 1020075:
      return "MP5K精致";
      break;
    case 1020076:
      return "MP5K独眼";
      break;
    case 1020077:
      return "MP5K钢铁";
      break;

    case 102002:
      return "UMP-45";
      break;
    case 1020021:
      return "UMP-45破损";
      break;
    case 1020022:
      return "UMP-45修复";
      break;
    case 1020023:
      return "UMP-45完好";
      break;
    case 1020024:
      return "UMP-45改进";
      break;
    case 1020025:
      return "UMP-45精致";
      break;
    case 1020026:
      return "UMP-45独眼";
      break;
    case 1020027:
      return "UMP-45钢铁";
      break;

    case 102004:
      return "汤姆逊";
      break;
    case 1020041:
      return "汤姆逊破损";
      break;
    case 1020042:
      return "汤姆逊修复";
      break;
    case 1020043:
      return "汤姆逊完好";
      break;
    case 1020044:
      return "汤姆逊改进";
      break;
    case 1020045:
      return "汤姆逊精致";
      break;
    case 1020046:
      return "汤姆逊独眼";
      break;
    case 1020047:
      return "汤姆逊钢铁";
      break;

    case 102105:
      return "P90";
      break;
    case 1021051:
      return "P90破损";
      break;
    case 1021052:
      return "P90修复";
      break;
    case 1021053:
      return "P90完好";
      break;
    case 1021054:
      return "P90改进";
      break;
    case 1021055:
      return "P90精致";
      break;
    case 1021056:
      return "P90独眼";
      break;
    case 1021057:
      return "P90钢铁";
      break;

    case 102005:
      return "野牛";
      break;
    case 1020051:
      return "野牛破损";
      break;
    case 1020052:
      return "野牛修复";
      break;
    case 1020053:
      return "野牛完好";
      break;
    case 1020054:
      return "野牛改进";
      break;
    case 1020055:
      return "野牛精致";
      break;
    case 1020056:
      return "野牛独眼";
      break;
    case 1020057:
      return "野牛钢铁";
      break;
//霰弹枪
    case 104001:
      return "S686";
      break;
    case 1040011:
      return "S686破损";
      break;
    case 1040012:
      return "S686修复";
      break;
    case 1040013:
      return "S686完好";
      break;
    case 1040014:
      return "S686改进";
      break;
    case 1040015:
      return "S686精致";
      break;
    case 1040016:
      return "S686独眼";
      break;
    case 1040017:
      return "S686钢铁";
      break;

    case 104002:
      return "S1897";
      break;
    case 1040021:
      return "S1897破损";
      break;
    case 1040022:
      return "S1897修复";
      break;
    case 1040023:
      return "S1897完好";
      break;
    case 1040024:
      return "S1897改进";
      break;
    case 1040025:
      return "S1897精致";
      break;
    case 1040026:
      return "S1897独眼";
      break;
    case 1040027:
      return "S1897钢铁";
      break;

    case 104003:
      return "S12K";
      break;
    case 1040031:
      return "S12K破损";
      break;
    case 1040032:
      return "S12K修复";
      break;
    case 1040033:
      return "S12K完好";
      break;
    case 1040034:
      return "S12K改进";
      break;
    case 1040035:
      return "S12K精致";
      break;
    case 1040036:
      return "S12K独眼";
      break;
    case 1040037:
      return "S12K钢铁";
      break;

    case 104004:
      return "DBS";
      break;
    case 1040041:
      return "DBS破损";
      break;
    case 1040042:
      return "DBS修复";
      break;
    case 1040043:
      return "DBS完好";
      break;
    case 1040044:
      return "DBS改进";
      break;
    case 1040045:
      return "DBS精致";
      break;
    case 1040046:
      return "DBS独眼";
      break;
    case 1040047:
      return "DBS钢铁";
      break;

    case 104100:
      return "SPAS-12";
      break;
    case 1041001:
      return "SPAS-12破损";
      break;
    case 1041002:
      return "SPAS-12修复";
      break;
    case 1041003:
      return "SPAS-12完好";
      break;
    case 1041004:
      return "SPAS-12改进";
      break;
    case 1041005:
      return "SPAS-12精致";
      break;
    case 1041006:
      return "SPAS-12独眼";
      break;
    case 1041007:
      return "SPAS-12钢铁";
      break;
//投掷爆炸物
    case 602004:
      return "手榴弹";
      break;
    case 602003:
      return "燃烧瓶";
      break;
    case 602002:
      return "烟雾弹";
      break;
    case 602001:
      return "震撼弹";
      break;
//近战武器
    case 108003:
      return "镰刀";
      break;
    case 108002:
      return "撬棍";
      break;
    case 108001:
      return "大砍刀";
      break;
    case 108004:
      return "平底锅";
      break;
    case 0:
      return "拳头";
      break;
      case 9808001:
return "P92手枪(破损)";
      break;
case 9808002:
return "P92手枪(修复)";
      break;
case 9808003:
return "P92手枪(完好)";
      break;
case 9808008:
return "P1911手枪(破损)";
      break;
case 9808009:
return "P1911手枪(修复)";
      break;
case 9808010:
return "P1911手枪(完好)";
      break;
case 9808015:
return "R1895手枪(破损)";
      break;
case 9808016:
return "R1895手枪(修复)";
      break;
case 9808017:
return "R1895手枪(完好)";
      break;
case 9808022:
return "P18C手枪(破损)";
      break;
case 9808023:
return "P18C手枪(修复)";
      break;
case 9808024:
return "P18C手枪(完好)";
      break;
case 9808029:
return "R45手枪(破损)";
      break;
case 9808030:
return "R45手枪(修复)";
      break;
case 9808031:
return "R45手枪(完好)";
      break;
case 9808036:
return "短管霰弹枪(破损)";
      break;
case 9808037:
return "短管霰弹枪(修复)";
      break;
case 9808038:
return "短管霰弹枪(完好)";
      break;
case 9808043:
return "蝎式手枪(修复)";
      break;
case 9808044:
return "蝎式手枪(完好)";
      break;
case 9808045:
return "蝎式手枪(改进)";
      break;
case 9808046:
return "蝎式手枪(破损)";
      break;
case 9808050:
return "沙漠之鹰手枪(修复)";
      break;
case 9808051:
return "沙漠之鹰手枪(完好)";
      break;
case 9808052:
return "沙漠之鹰手枪(改进)";
      break;
case 9808053:
return "沙漠之鹰手枪(破损)";
      break;
case 9808057:
return "TMP-9手枪(修复)";
      break;
case 9808058:
return "TMP-9手枪(完好)";
      break;
case 9808059:
return "TMP-9手枪(改进)";
      break;
case 9808060:
return "空投信号枪";
      break;
case 9808061:
return "TMP-9手枪(破损)";
      break;
case 9809001:
return "十字弩(破损)";
      break;
case 9809002:
return "十字弩(修复)";
      break;
case 9809003:
return "十字弩(完好)";
      break;
case 9809009:
return "爆炸猎弓(骑警Boss)";
      break;
case 9809010:
return "爆炸猎弓·杰西";
      break;
case 9810001:
return "S686霰弹枪(破损)";
      break;
case 9810002:
return "S686霰弹枪(修复)";
      break;
case 9810003:
return "S686霰弹枪(完好)";
      break;
case 9810008:
return "S1897霰弹枪(破损)";
      break;
case 9810009:
return "S1897霰弹枪(修复)";
      break;
case 9810010:
return "S1897霰弹枪(完好)";
      break;
case 9810015:
return "S12K霰弹枪(精制)";
      break;
case 9810016:
return "S12K霰弹枪(修复)";
      break;
case 9810017:
return "S12K霰弹枪(完好)";
      break;
case 9810018:
return "S12K霰弹枪(改进)";
      break;
case 9810022:
return "DBS霰弹枪(修复)";
      break;
case 9810023:
return "DBS霰弹枪(完好)";
      break;
case 9810024:
return "DBS霰弹枪(改进)";
      break;
case 9810025:
return "DBS霰弹枪(精制)";
      break;
case 9810029:
return "SPAS-12霰弹枪(修复)";
      break;
case 9810030:
return "SPAS-12霰弹枪(完好)";
      break;
case 9810031:
return "SPAS-12霰弹枪(改进)";
      break;
case 9810032:
return "SPAS-12霰弹枪(精制)";
      break;
case 9810036:
return "AA12-G霰弹枪(修复)";
      break;
case 9810037:
return "AA12-G霰弹枪(完好)";
      break;
case 9810038:
return "AA12-G霰弹枪(改进)";
      break;
case 9810041:
return "AA12-G霰弹枪(精制)";
      break;
case 9811001:
return "UZI冲锋枪(破损)";
      break;
case 9811002:
return "UZI冲锋枪(修复)";
      break;
case 9811003:
return "UZI冲锋枪(完好)";
      break;
case 9811004:
return "UZI冲锋枪(改进)";
      break;
case 9811008:
return "UMP45冲锋枪(破损)";
      break;
case 9811009:
return "UMP45冲锋枪(修复)";
      break;
case 9811010:
return "UMP45冲锋枪(完好)";
      break;
case 9811011:
return "UMP45冲锋枪(改进)";
      break;
case 9811015:
return "Vector冲锋枪(卓越)";
      break;
case 9811016:
return "Vector冲锋枪(完好)";
      break;
case 9811017:
return "Vector冲锋枪(改进)";
      break;
case 9811018:
return "Vector冲锋枪(精制)";
      break;
case 9811019:
return "Vector冲锋枪(卓越)";
      break;
case 9811020:
return "Vector冲锋枪(黑鹰)";
      break;
case 9811021:
return "Vector冲锋枪(铁爪)";
      break;
case 9811022:
return "汤姆逊冲锋枪(破损)";
      break;
case 9811023:
return "汤姆逊冲锋枪(修复)";
      break;
case 9811024:
return "汤姆逊冲锋枪(完好)";
      break;
case 9811025:
return "汤姆逊冲锋枪(改进)";
      break;
case 9811029:
return "野牛冲锋枪(破损)";
      break;
case 9811030:
return "野牛冲锋枪(修复)";
      break;
case 9811031:
return "野牛冲锋枪(完好)";
      break;
case 9811036:
return "MP5K冲锋枪(卓越)";
      break;
case 9811037:
return "MP5K冲锋枪(完好)";
      break;
case 9811038:
return "MP5K冲锋枪(改进)";
      break;
case 9811039:
return "MP5K冲锋枪(精制)";
      break;
case 9811040:
return "MP5K冲锋枪(卓越)";
      break;
case 9811041:
return "MP5K冲锋枪(黑鹰)";
      break;
case 9811042:
return "MP5K冲锋枪(铁爪)";
      break;
case 9811043:
return "AKS-74U冲锋枪(卓越)";
      break;
case 9811044:
return "AKS-74U冲锋枪(完好)";
      break;
case 9811045:
return "AKS-74U冲锋枪(改进)";
      break;
case 9811046:
return "AKS-74U冲锋枪(精制)";
      break;
case 9811047:
return "AKS-74U冲锋枪(卓越)";
      break;
case 9811048:
return "AKS-74U冲锋枪(铁爪)";
      break;
case 9811049:
return "AKS-74U冲锋枪(黑鹰)";
      break;
case 9811050:
return "P90冲锋枪(卓越)";
      break;
case 9811051:
return "P90冲锋枪(完好)";
      break;
case 9811052:
return "P90冲锋枪(改进)";
      break;
case 9811053:
return "P90冲锋枪(精制)";
      break;
case 9811054:
return "P90冲锋枪(卓越)";
      break;
case 9811055:
return "P90冲锋枪(黑鹰)";
      break;
case 9811056:
return "P90冲锋枪(铁爪)";
      break;
case 9812002:
return "AKM突击步枪(卓越)";
      break;
case 9812003:
return "AKM突击步枪(完好)";
      break;
case 9812004:
return "AKM突击步枪(改进)";
      break;
case 9812005:
return "AKM突击步枪(精制)";
      break;
case 9812006:
return "AKM突击步枪(卓越)";
      break;
case 9812007:
return "AKM突击步枪(黑鹰)";
      break;
case 9812008:
return "AKM突击步枪(铁爪)";
      break;
case 9812009:
return "M16A4突击步枪(破损)";
      break;
case 9812010:
return "M16A4突击步枪(修复)";
      break;
case 9812011:
return "M16A4突击步枪(完好)";
      break;
case 9812012:
return "M16A4突击步枪(改进)";
      break;
case 9812015:
return "SCAR-L突击步枪(卓越)";
      break;
case 9812016:
return "SCAR-L突击步枪(完好)";
      break;
case 9812017:
return "SCAR-L突击步枪(改进)";
      break;
case 9812018:
return "SCAR-L突击步枪(精制)";
      break;
case 9812019:
return "SCAR-L突击步枪(卓越)";
      break;
case 9812020:
return "SCAR-L突击步枪(黑鹰)";
      break;
case 9812021:
return "SCAR-L突击步枪(铁爪)";
      break;
case 9812022:
return "M416突击步枪(铁爪)";
      break;
case 9812023:
return "M416突击步枪(卓越)";
      break;
case 9812024:
return "M416突击步枪(完好)";
      break;
case 9812025:
return "M416突击步枪(改进)";
      break;
case 9812026:
return "M416突击步枪(精制)";
      break;
case 9812027:
return "M416突击步枪(卓越)";
      break;
case 9812028:
return "M416突击步枪(黑鹰)";
      break;
case 9812029:
return "GROZA突击步枪(卓越)";
      break;
case 9812030:
return "GROZA突击步枪(改进)";
      break;
case 9812031:
return "GROZA突击步枪(精制)";
      break;
case 9812032:
return "GROZA突击步枪(卓越)";
      break;
case 9812033:
return "GROZA突击步枪(黑鹰)";
      break;
case 9812034:
return "GROZA突击步枪(铁爪)";
      break;
case 9812036:
return "AUG突击步枪(卓越)";
      break;
case 9812037:
return "AUG突击步枪(改进)";
      break;
case 9812038:
return "AUG突击步枪(精制)";
      break;
case 9812039:
return "AUG突击步枪(卓越)";
      break;
case 9812040:
return "AUG突击步枪(黑鹰)";
      break;
case 9812041:
return "AUG突击步枪(铁爪)";
      break;
case 9812043:
return "QBZ突击步枪(卓越)";
      break;
case 9812044:
return "QBZ突击步枪(完好)";
      break;
case 9812045:
return "QBZ突击步枪(改进)";
      break;
case 9812046:
return "QBZ突击步枪(精制)";
      break;
case 9812047:
return "QBZ突击步枪(卓越)";
      break;
case 9812048:
return "QBZ突击步枪(黑鹰)";
      break;
case 9812049:
return "QBZ突击步枪(铁爪)";
      break;
case 9812050:
return "M762突击步枪(卓越)";
      break;
case 9812051:
return "M762突击步枪(完好)";
      break;
case 9812052:
return "M762突击步枪(改进)";
      break;
case 9812053:
return "M762突击步枪(精制)";
      break;
case 9812054:
return "M762突击步枪(卓越)";
      break;
case 9812055:
return "M762突击步枪(黑鹰)";
      break;
case 9812056:
return "M762突击步枪(铁爪)";
      break;
case 9812057:
return "Mk47突击步枪(破损)";
      break;
case 9812058:
return "Mk47突击步枪(修复)";
      break;
case 9812059:
return "Mk47突击步枪(完好)";
      break;
case 9812060:
return "Mk47突击步枪(改进)";
      break;
case 9812064:
return "G36C突击步枪(卓越)";
      break;
case 9812065:
return "G36C突击步枪(完好)";
      break;
case 9812066:
return "G36C突击步枪(改进)";
      break;
case 9812067:
return "G36C突击步枪(精制)";
      break;
case 9812068:
return "G36C突击步枪(卓越)";
      break;
case 9812069:
return "G36C突击步枪(黑鹰)";
      break;
case 9812070:
return "G36C突击步枪(铁爪)";
      break;
case 9812071:
return "AC-VAL突击步枪(破损)";
      break;
case 9812072:
return "AC-VAL突击步枪(修复)";
      break;
case 9812073:
return "AC-VAL突击步枪(完好)";
      break;
case 9812074:
return "AC-VAL突击步枪(改进)";
      break;
case 9812078:
return "蜜獾突击步枪(卓越)";
      break;
case 9812079:
return "蜜獾突击步枪(完好)";
      break;
case 9812080:
return "蜜獾突击步枪(改进)";
      break;
case 9812081:
return "蜜獾突击步枪(精制)";
      break;
case 9812082:
return "蜜獾突击步枪(卓越)";
      break;
case 9812083:
return "蜜獾突击步枪(黑鹰)";
      break;
case 9812084:
return "蜜獾突击步枪(铁爪)";
      break;
case 9812085:
return "FAMAS突击步枪(卓越)";
      break;
case 9812086:
return "FAMAS突击步枪(完好)";
      break;
case 9812087:
return "FAMAS突击步枪(改进)";
      break;
case 9812088:
return "FAMAS突击步枪(精制)";
      break;
case 9812089:
return "FAMAS突击步枪(卓越)";
      break;
case 9812090:
return "FAMAS突击步枪(黑鹰)";
      break;
case 9812091:
return "FAMAS突击步枪(铁爪)";
      break;
case 9812092:
return "M416突击步枪·卡德尔";
      break;
case 9813001:
return "M249轻机枪(卓越)";
      break;
case 9813002:
return "M249轻机枪(改进)";
      break;
case 9813003:
return "M249轻机枪(精制)";
      break;
case 9813004:
return "M249轻机枪(卓越)";
      break;
case 9813005:
return "M249轻机枪(黑鹰)";
      break;
case 9813006:
return "M249轻机枪(铁爪)";
      break;
case 9813008:
return "DP-28轻机枪(破损)";
      break;
case 9813009:
return "DP-28轻机枪(修复)";
      break;
case 9813010:
return "DP-28轻机枪(完好)";
      break;
case 9813022:
return "MG3轻机枪(卓越)";
      break;
case 9813023:
return "MG3轻机枪(改进)";
      break;
case 9813024:
return "MG3轻机枪(精制)";
      break;
case 9813025:
return "MG3轻机枪(卓越)";
      break;
case 9813026:
return "MG3轻机枪(黑鹰)";
      break;
case 9813027:
return "MG3轻机枪(铁爪)";
      break;
case 9813029:
return "PKM轻机枪(卓越)";
      break;
case 9813030:
return "PKM轻机枪(改进)";
      break;
case 9813031:
return "PKM轻机枪(精制)";
      break;
case 9813032:
return "PKM轻机枪(卓越)";
      break;
case 9813033:
return "PKM轻机枪(黑鹰)";
      break;
case 9813034:
return "PKM轻机枪(铁爪)";
      break;
case 9814001:
return "Kar98K狙击枪(修复)";
      break;
case 9814002:
return "Kar98K狙击枪(完好)";
      break;
case 9814003:
return "Kar98K狙击枪(改进)";
      break;
case 9814008:
return "M24狙击枪(卓越)";
      break;
case 9814009:
return "M24狙击枪(完好)";
      break;
case 9814010:
return "M24狙击枪(改进)";
      break;
case 9814011:
return "M24狙击枪(精制)";
      break;
case 9814012:
return "M24狙击枪(卓越)";
      break;
case 9814013:
return "M24狙击枪(黑鹰)";
      break;
case 9814014:
return "M24狙击枪(铁爪)";
      break;
case 9814015:
return "AWM狙击枪(卓越)";
      break;
case 9814016:
return "AWM狙击枪(改进)";
      break;
case 9814017:
return "AWM狙击枪(精制)";
      break;
case 9814018:
return "AWM狙击枪(卓越)";
      break;
case 9814019:
return "AWM狙击枪(黑鹰)";
      break;
case 9814020:
return "AWM狙击枪(铁爪)";
      break;
case 9814022:
return "莫辛纳甘狙击枪(破损)";
      break;
case 9814023:
return "莫辛纳甘狙击枪(修复)";
      break;
case 9814024:
return "莫辛纳甘狙击枪(完好)";
      break;
case 9814029:
return "Win94狙击枪(破损)";
      break;
case 9814030:
return "Win94狙击枪(修复)";
      break;
case 9814031:
return "Win94狙击枪(完好)";
      break;
case 9814036:
return "AMR狙击枪(卓越)";
      break;
case 9814037:
return "AMR狙击枪(改进)";
      break;
case 9814038:
return "AMR狙击枪(精制)";
      break;
case 9814039:
return "AMR狙击枪(卓越)";
      break;
case 9814040:
return "AMR狙击枪(黑鹰)";
      break;
case 9814041:
return "AMR狙击枪(铁爪)";
      break;
case 9814043:
return "M200狙击枪(卓越)";
      break;
case 9814044:
return "M200狙击枪(完好)";
      break;
case 9814045:
return "M200狙击枪(改进)";
      break;
case 9814046:
return "M200狙击枪(精制)";
      break;
case 9814047:
return "M200狙击枪(卓越)";
      break;
case 9814048:
return "M200狙击枪(黑鹰)";
      break;
case 9814049:
return "M200狙击枪(铁爪)";
      break;
case 9814050:
return "SVD狙击枪(改进)";
      break;
case 9814051:
return "SVD狙击枪(精制)";
      break;
case 9814052:
return "SVD狙击枪(卓越)";
      break;
case 9814053:
return "SVD狙击枪(卓越)";
      break;
case 9815001:
return "SKS射手步枪(卓越)";
      break;
case 9815002:
return "SKS射手步枪(完好)";
      break;
case 9815003:
return "SKS射手步枪(改进)";
      break;
case 9815004:
return "SKS射手步枪(精制)";
      break;
case 9815005:
return "SKS射手步枪(卓越)";
      break;
case 9815006:
return "SKS射手步枪(黑鹰)";
      break;
case 9815007:
return "SKS射手步枪(铁爪)";
      break;
case 9815008:
return "VSS射手步枪(破损)";
      break;
case 9815009:
return "VSS射手步枪(修复)";
      break;
case 9815010:
return "VSS射手步枪(完好)";
      break;
case 9815015:
return "Mini14射手步枪(破损)";
      break;
case 9815016:
return "Mini14射手步枪(修复)";
      break;
case 9815017:
return "Mini14射手步枪(完好)";
      break;
case 9815018:
return "Mini14射手步枪(改进)";
      break;
case 9815022:
return "Mk14射手步枪(卓越)";
      break;
case 9815023:
return "Mk14射手步枪(完好)";
      break;
case 9815024:
return "Mk14射手步枪(改进)";
      break;
case 9815025:
return "Mk14射手步枪(精制)";
      break;
case 9815026:
return "Mk14射手步枪(卓越)";
      break;
case 9815027:
return "Mk14射手步枪(黑鹰)";
      break;
case 9815028:
return "Mk14射手步枪(铁爪)";
      break;
case 9815029:
return "SLR射手步枪(卓越)";
      break;
case 9815030:
return "SLR射手步枪(完好)";
      break;
case 9815031:
return "SLR射手步枪(改进)";
      break;
case 9815032:
return "SLR射手步枪(精制)";
      break;
case 9815033:
return "SLR射手步枪(卓越)";
      break;
case 9815034:
return "SLR射手步枪(黑鹰)";
      break;
case 9815035:
return "SLR射手步枪(铁爪)";
      break;
case 9815036:
return "QBU射手步枪(破损)";
      break;
case 9815037:
return "QBU射手步枪(修复)";
      break;
case 9815038:
return "QBU射手步枪(完好)";
      break;
case 9815039:
return "QBU射手步枪(改进)";
      break;
case 9815043:
return "M417射手步枪(卓越)";
      break;
case 9815044:
return "M417射手步枪(完好)";
      break;
case 9815045:
return "M417射手步枪(改进)";
      break;
case 9815046:
return "M417射手步枪(精制)";
      break;
case 9815047:
return "M417射手步枪(卓越)";
      break;
case 9815048:
return "M417射手步枪(黑鹰)";
      break;
case 9815049:
return "M417射手步枪(铁爪)";
      break;
case 9815050:
return "MK20-H射手步枪(卓越)";
      break;
case 9815051:
return "MK20-H射手步枪(完好)";
      break;
case 9815052:
return "MK20-H射手步枪(改进)";
      break;
case 9815053:
return "MK20-H射手步枪(精制)";
      break;
case 9815054:
return "MK20-H射手步枪(卓越)";
      break;
case 9815055:
return "MK20-H射手步枪(黑鹰)";
      break;
case 9815056:
return "MK20-H射手步枪(铁爪)";
      break;
case 9815064:
return "MK12射手步枪(卓越)";
      break;
case 9815065:
return "MK12射手步枪(完好)";
      break;
case 9815066:
return "MK12射手步枪(改进)";
      break;
case 9815067:
return "MK12射手步枪(精制)";
      break;
case 9815068:
return "MK12射手步枪(卓越)";
      break;
case 9815069:
return "MK12射手步枪(黑鹰)";
      break;
case 9815070:
return "MK12射手步枪(铁爪)";
      break;
case 9815071:
return "M134_装甲重机枪";
      break;
    default:
      return "未收录";
      break;
  }
  return nullptr;
} 





#endif