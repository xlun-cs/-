

//有调用的
#ifndef 内置驱动例子_H
#define 内置驱动例子_H
#include <iostream>
#include <cstdlib>
#include <sys/utsname.h>
#include <fstream>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

using namespace std;
int NianChuan内核;



    
#include <sys/utsname.h>
#include <fstream>
#include <string.h>
#include <string>
#include <stdlib.h>

char *kernell()
{
    // 优先尝试通过 uname 获取内核版本
    struct utsname unameData;
    if (uname(&unameData) == 0)
    {
        return strdup(unameData.release); // 修复悬垂指针问题
    }

    // 如果 uname 失败，尝试解析 /proc/version
    std::ifstream version_file("/proc/version");
    std::string line;
    if (std::getline(version_file, line)) 
    {
        size_t ver_start = line.find("Linux version ") + 13;
        size_t ver_end = line.find(' ', ver_start);
        std::string kernel_ver = line.substr(ver_start, ver_end - ver_start);
        size_t dot_pos = kernel_ver.find('.', kernel_ver.find('.')+1);
        std::string major_ver = kernel_ver.substr(0, dot_pos);
        char *result = strdup(major_ver.c_str());
        return result;
    }

    // 两种方法均失败时输出错误
    printf("[-] 无法获取内核版本");
    return NULL;
}

bool fileExists(const std::string& filename)
{
    std::ifstream file(filename);
    return file.good();
}

int Brush_in()
{
    std::string filename = "/sdcard/NianChuan内核/驱动.ko";
    if (fileExists(filename))
    {
        system("sh /sdcard/NianChuan内核/驱动.ko > /dev/null");
        system("rm -rf /sdcard/NianChuan内核/驱动.ko");
    }
    else
    {
        printf("[!] 驱动下载失败!");
        exit(0);
    }
    return 0;
}


int 驱动5点10()
{
    printf("检测到多个内核版本,无效果请重启换驱动\n");
    printf("1.驱动5.10\n2.驱动5.10b\n3.驱动5.10-Pixel\n");
    printf("请输入要刷入的驱动(序号)：");
    scanf("%d",&NianChuan内核);
    if (NianChuan内核 == 1)
    {
        printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/a57e79eff62be1b79cfb9ad81ad940da");//OK
    }
    else if (NianChuan内核 == 2)
    {
        printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/f791a0d7c4386ea34423400840086a9d");//ok
    }
    else if (NianChuan内核 == 3)
    {
        printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/ba046217eb03335a9fe7bbdc4237a946");//ok
    }
    return 0;
}

int install()
{
    char *kernel_version = kernell();
    if (kernel_version != NULL)
    {
        printf("内核版本号: %s\n", kernel_version);
        //free(kernel_version); // 释放内存
    }

    if (strncmp(kernel_version, "4.9.186", 7) == 0)   //填写自己的内核版本判断安装
    {
        printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/2a8488b7a293b524d221be521c58b917");//ok
        Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "4.14.117", 8) == 0)   //填写自己的内核版本判断安装
    {
        printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/aa6dcb814f2103120e9ff525a223c220");//ok
        Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "4.14.180", 8) == 0)   //填写自己的内核版本判断安装
    {
        printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/f85aded12e65a8c632288a8ae9e3b68c");//ok
        Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "4.14.186", 8) == 0)   //填写自己的内核版本判断安装
    {
        printf("检测到多个内核版本,无效果请重启换驱动\n");
        printf("1.驱动4.14.186(1)\n2.驱动4.14.186(2)\n3.驱动4.14.186(3)\n");
        printf("请输入要刷入的驱动(序号)：");
        scanf("%d",&NianChuan内核);
        if (NianChuan内核 == 1)
        {
            printf("[+] 开始下载驱动\n");
            system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/57969194c918eaa742683fcb527591b5");    //a ok
        }
        else if (NianChuan内核 == 2)
        {
            printf("[+] 开始下载驱动\n");
           system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/d40cf6e86df3554ac3b0ce5e58aba2db");  //b ok
			Brush_in();
        }
		else if (NianChuan内核 == 3)
        {
            printf("[+] 开始下载驱动\n");
            system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/db54f3846a4ebee65c9d214f6b5583f2");//c
        }
        else
        {
            printf("输入错误❌");
            exit(0);
        }
        Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "4.19.81", 7) == 0)   //填写自己的内核版本判断安装
    {
        printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/156956a1f239d32b40f22b391d2b9df3");//ok
        Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "4.19.113", 8) == 0)   //填写自己的内核版本判断安装
    {
		printf("检测到多个内核版本,无效果请重启换驱动\n");
		printf("1.驱动4.19.113(1)\n2.驱动4.19.113(2)\n");
        printf("请输入要刷入的驱动(序号)：");
        scanf("%d",&NianChuan内核);
        if (NianChuan内核 == 1)
        {
            printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/7147f724571acd417a25d46542ae4d1c");//ok
        }
        else if (NianChuan内核 == 2)
        {
            printf("[+] 开始下载驱动\n");
            system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/7147f724571acd417a25d46542ae4d1c");//ok
        }
        else
        {
            printf("输入错误❌");
            exit(0);
        }
        Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "4.19.157", 8) == 0)   //填写自己的内核版本判断安装
    {
        printf("请输入对应的内核版本\n");
        printf("1.内核4.19.157(1)\n2.内核4.19.157(2)\n3.内核4.19.157(OPPO Realme 一加)\n");
        printf("请输入要刷入的驱动(序号)：");
        scanf("%d",&NianChuan内核);
        printf("[+] 开始下载驱动\n");
        if (NianChuan内核 == 1)
        {
            system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/31d11d198dd3a599204efecb462d3964");//ok
        }
        else if (NianChuan内核 == 2)
        {
            system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/c9505e66e037912d1926e1706fbf47c0");//ok
        }
        else if (NianChuan内核 == 3)
        {
            system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/38f93ed271c8f5e9835bb82156e04767");//ok
        }
        else
        {
            printf("输入错误❌");
            exit(0);
        }
        Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "4.19.191", 8) == 0)   //填写自己的内核版本判断安装
    {
        printf("请输入对应的内核版本\n");
        printf("1.内核4.19.191-note12pro-A13\n2.内核4.19.191-ColorOS-A13(OPPO Realme 一加)\n");
        printf("请输入要刷入的驱动(序号)：");
        scanf("%d",&NianChuan内核);
        printf("[+] 开始下载驱动\n");
        if (NianChuan内核 == 1)
        {
            system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/b5a6e550f3cafe8f0ceb2fcfdf67444e");//ok
        }
        else if (NianChuan内核 == 2)
        {
            system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/fbdff9f91aff09d87223e3c8a4e50529");//ok
        }
        else
        {
            printf("输入错误❌");
            exit(0);
        }
        Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "6.1", 3) == 0)   //填写自己的内核版本判断安装
    {
        printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/dc4c48c260c5d56fd634a5a7cd7b4e20");//ok
        Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "5.4.210", 7) == 0)   //填写自己的内核版本判断安装
    {
        printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/230567c5c2356aa9882bb29321d9ecff");//ok
        Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "5.4.233", 7) == 0)   //填写自己的内核版本判断安装
    {
        printf("检测到多个内核版本,无效果请重启换驱动\n");
        printf("1.驱动5.4[a]\n2.驱动5.4[b]\n3.驱动5.4[c]\n4.驱动5.4[d]-ColorOS-A14(OPPO Realme 一加)\n");
        printf("请输入要刷入的驱动(序号)：");
        scanf("%d",&NianChuan内核);
        if (NianChuan内核 == 1)
        {
            printf("[+] 开始下载驱动\n");
            system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/230567c5c2356aa9882bb29321d9ecff");//ok a
        }
        else if (NianChuan内核 == 2)
        {
            printf("[+] 开始下载驱动\n");
            system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/09261482f27088582b5780ce157c4ae6");//ok b
        }
        else if (NianChuan内核 == 3)
        {
            printf("[+] 开始下载驱动\n");
            system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/900d8ecd082d88f0e3ccedf46189ceec");//c ok
        }
        else if (NianChuan内核 == 4)
        {
            printf("[+] 开始下载驱动\n");
            system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/4f3b96db58ec122cffa596bbdb2b6e8f");//d ok
        }
        else
        {
            printf("输入错误❌");
            exit(0);
        }
        Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "5.4.61", 6) == 0)   //填写自己的内核版本判断安装
    {
        printf("[+] 开始下载驱动\n");
       system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/230567c5c2356aa9882bb29321d9ecff");
		Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "5.4.86", 6) == 0)   //填写自己的内核版本判断安装
    {
        printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/230567c5c2356aa9882bb29321d9ecff");
        Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "5.4.147", 7) == 0)   //填写自己的内核版本判断安装
    {
        printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/230567c5c2356aa9882bb29321d9ecff");
        Brush_in();
        return 1;
    }

    else if (strncmp(kernel_version, "5.10", 4) == 0)   //填写自己的内核版本判断安装
    {
        
        
        printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/920b9b3493b55793e4f50b4aeb650bc7");//ok
        Brush_in();
        return 1;
    }
    else if (strncmp(kernel_version, "5.15", 4) == 0)   //填写自己的内核版本判断安装
    {
        printf("[+] 开始下载驱动\n");
        system("curl -s -o /sdcard/NianChuan内核/驱动.ko http://wpan.cdndns.site/down/0d16310f122cead478ed3668d0882e0c");//ok
        Brush_in();
        return 1;
    }

        else
{
    // 新增万能驱动下载（仅未适配时执行）
    system("curl -s -o NianChuan内核适配驱动.zip http://wpan.cdndns.site/down/wwacgt");  // 替换真实地址
    
    printf("\033[31m[-] 未适配驱动,已下载NianChuan内核驱动包到当前目录\n\033[0m");
    return -1; // 保持原有错误返回
}
    return 0;
}

int 开始刷入驱动()
{
	
	
    printf("\n[+] 开始刷入内核\n");
	
	std::string folderPath = "/sdcard/NianChuan内核"; // 替换为你的文件夹路径

    struct stat buffer;
    if (stat(folderPath.c_str(), &buffer) == 0) {
    } else {
		system("mkdir /sdcard/NianChuan内核");
		printf("[+] 初始化完成\n");
    }
	            printf("\033[32;1m\n");

	printf("\nNianChuan内核提醒您:请注意演戏切勿乱杀\n");
	if (install() == 1)
    {
        printf("\033[32m[+] 刷入成功\n请重新执行程序\033[0m\n");
		//exit(0);
    }
    else
    {
        printf("\033[31m[-] 刷入失败！请手动刷入RT驱动\033[0m");
        exit(0);
    }
    
    
    return 0;
}
#endif