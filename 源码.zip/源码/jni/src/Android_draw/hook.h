//NianChuan
//频道 @XIAOMODS520//NianChuan
//频道 @XIAOMODS520//NianChuan
//频道 @XIAOMODS520//NianChuan
//频道 @XIAOMODS520//NianChuan
//频道 @XIAOMODS520//NianChuan
//频道 @XIAOMODS520//NianChuan
//频道 @XIAOMODS520//NianChuan
//频道 @XIAOMODS520//NianChuan
//频道 @XIAOMODS520//NianChuan
//频道 @XIAOMODS520
AimCount = 0;
lunxian.PlayerCount = 0;
lunxian.BotCount = 0;
float cornerRadius = 7.0f;
lunxian.Gname = driver->read<uintptr_t>(lunxian.libUE4 + 0x123CFA48);//OK
lunxian.Uworld = driver->read<uintptr_t>(lunxian.libUE4 + 0x12AFBBF8);//世界矩阵
lunxian.Uleve = driver->read<uintptr_t>(lunxian.Uworld + 0x90);
lunxian.Arrayaddr = driver->read<uintptr_t>(lunxian.Uleve + 0xA0);//数组地址
lunxian.Count = driver->read<int>(lunxian.Uleve + 0xA8);//世界数量

lunxian.Oneself = driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.libUE4 + 0x12AFBBF8) + 0x98)+0x88)+0x30)+0x3348);//0x98 + 0x88 +0x30 + 0x2F10
lunxian.MyTeam = driver->read<int>(lunxian.Oneself + 0xac0);//队伍阵营 //OK
// lunxian.MyWeapon = driver->read<int>(driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.Oneself + 0x2eb0)+ 0x668)+ 0xba0); //手持
driver->read(driver->read<uintptr_t>(lunxian.Oneself + 0x278) + 0x200, &lunxian.MyPos, 12);//读写.readv(读写.getPtr64(对象地址.敌人地址 + 0x278) + 0x1F0, &对象信息.敌人信息.坐标, sizeof(对象信息.敌人信息.坐标));  // 更新坐标  坐标加真实坐标


driver->read(lunxian.Matrixs, &lunxian.matrix, 16 * 4);

// 自身fov，开火，开镜，雷达旋转值
lunxian.Fov = driver->read<float>(driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.Oneself + 0x5708) + 0x608) + 0x630);
lunxian.IsFiring = driver->read<int>(lunxian.Oneself + 0x2448);//开火 
lunxian.IsAiming = driver->read<int>(lunxian.Oneself + 0x16b8);//开镜
lunxian.angle = driver->read<float>(driver->read<uintptr_t>(lunxian.Oneself + 0x5588)+ 0x5a8) - 90;


char *CasName;

for (int i = 0; i < lunxian.Count; i ++) {
lunxian.Objaddr = driver->read<uintptr_t>(lunxian.Arrayaddr + 0x8 * i);

if (lunxian.Oneself == lunxian.Objaddr || lunxian.Objaddr <= 0x10000000 || lunxian.Objaddr % 4 != 0 || lunxian.Objaddr >= 0x10000000000)
continue;

uintptr_t object = driver->read<uintptr_t>(lunxian.Objaddr + 0x278);
if (object <= 0xffff || object == 0 || object <= 0x10000000 || object % 4 != 0 || object >= 0x10000000000)
continue;

if (driver->read<float>(lunxian.Objaddr + 0x35dc) != 479.5) {
GetClassName(wz.Name, lunxian.Gname, driver->read<int>(lunxian.Objaddr + 0x18));
driver->read(object + 0x200, &wz.Pos, 12);
GetDistance(wz.Pos, lunxian.MyPos, &wz.Distance);
WorldToScreen(&wz.ScreenPos, &wz.camera, &wz.w, wz.Pos);
} else {

// 死亡不绘制
int State = driver->read<int>(lunxian.Objaddr + 0x1588);
if (State == 1048576 || State == 1048592 || State == 1048577 || State == 0)
continue;

// 自身队伍不绘制
lunxian.TeamID = driver->read<int>(lunxian.Objaddr + 0xac0);//OK
if (lunxian.TeamID == lunxian.MyTeam || lunxian.TeamID < 1)
continue;

if (DrawIo[1000]) {//观透
float 观透Team = NumIo[49];
// 自身队伍不绘制
lunxian.TeamID = driver->read<int>(lunxian.Objaddr + 0xac0);//OK
if (观透Team == lunxian.TeamID){
continue;
}
}

// 血量百分比大于百分之100不绘制
lunxian.Health = (driver->read<float>(lunxian.Objaddr + 0xf08) / driver->read<float>(lunxian.Objaddr + 0xf10)) * 100;//当前比最大血量？
if (lunxian.Health > 100)
continue;

driver->read(object + 0x200, &lunxian.Pos, 12); //读取坐标
GetDistance(lunxian.Pos, lunxian.MyPos, &lunxian.Distance); //用坐标计算出距离
WorldToScreen(&lunxian.ScreenPos, &lunxian.camera, &lunxian.w, lunxian.Pos); 

// 人机判断
if (driver->read<int>(lunxian.Objaddr +  0xadc)) lunxian.IsBot = 1; else lunxian.IsBot = 0;//OK
// 统计人数
if (lunxian.IsBot) lunxian.BotCount++; else lunxian.PlayerCount++;

//人机不绘制
if(DrawIo[17])
{
  // 是否为人机
if (lunxian.IsBot == 1)
{
 continue;
}
}

// 超出屏幕不绘制
if (lunxian.w < 0 || lunxian.w > screen_x)
continue;

if (driver->read<uintptr_t>(lunxian.Objaddr + 0x1000)) {
driver->read(driver->read<uintptr_t>(lunxian.Objaddr + 0xf30) + 0x1330, &lunxian.Predict, sizeof(lunxian.Predict)); // 载具向量
} else {
driver->read(object + 0x100c, &lunxian.Predict, sizeof(lunxian.Predict)); // 敌人向量 //OK
}

// 头甲包
long int rw = driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.Objaddr + 0x348) + 0x30) + 0x388);
lunxian.drb = driver->read<int>(rw + 0x1C4);
lunxian.drt = driver->read<int>(rw + 0x1FC);
lunxian.drj = driver->read<int>(rw + 0x234);
 
lunxian.敌方动作 = driver->read<int>(driver->read<uint64_t>(lunxian.Objaddr + 0x1588));
lunxian.dqzd = driver->read<int>(driver->read<uintptr_t>(lunxian.Objaddr + 0x1018) + 0x19e0);
lunxian.zdmax = driver->read<int>(driver->read<uintptr_t>(lunxian.Objaddr + 0x1018) + 0x19e4);

lunxian.scwq = driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.Objaddr + 0x1018) + 0xc28);
lunxian.Mesh = driver->read<uintptr_t>(lunxian.Objaddr + 0x600);
lunxian.Human = lunxian.Mesh + 0x1f0;
lunxian.Bone = driver->read<uintptr_t>(lunxian.Mesh + 0x810) + 0x30;
int BoneCount = driver->read<uint64_t>(lunxian.Mesh + 0x810+8);
getUTF8(lunxian.PlayerName, driver->read<uintptr_t>(lunxian.Objaddr + 0xa40));

int p = (BoneCount == 68) ? 33 : 32;
int o = (BoneCount == 68) ? 34 : 33;
int a = (BoneCount == 68) ? 13 : 63;
int b = (BoneCount == 68) ? 35 : 62;
int c = (BoneCount == 68) ? 55 : 52;
int d = (BoneCount == 68) ? 59 : 56;
int e = (BoneCount == 68) ? 56 : 53;
int f = (BoneCount == 68) ? 60 : 57;
int g = (BoneCount == 68) ? 57 : 54;
int h = (BoneCount == 68) ? 61 : 58;

FTransform meshtrans = getBone(lunxian.Human);
FMatrix c2wMatrix = TransformToMatrix(meshtrans);
FTransform headtrans = getBone(lunxian.Bone + 5 * 48);
FMatrix boneMatrix = TransformToMatrix(headtrans);
lunxian.Head.Pos = MarixToVector(MatrixMulti(boneMatrix, c2wMatrix));
lunxian.Head.Pos.z += 7; /* 脖子长度 */
lunxian.Head.ScreenPos = WorldToScreen(lunxian.Head.Pos, lunxian.matrix, lunxian.camera);

/* 胸部 */
FTransform chesttrans = getBone(lunxian.Bone + 4 * 48);
FMatrix boneMatrix1 = TransformToMatrix(chesttrans);
lunxian.Chest.Pos = MarixToVector(MatrixMulti(boneMatrix1, c2wMatrix));
lunxian.Chest.ScreenPos = WorldToScreen(lunxian.Chest.Pos, lunxian.matrix, lunxian.camera);

/* 盆骨 */
FTransform pelvistrans = getBone(lunxian.Bone + 0 * 48);
FMatrix boneMatrix2 = TransformToMatrix(pelvistrans);
lunxian.Pelvis.Pos = MarixToVector(MatrixMulti(boneMatrix2, c2wMatrix));
lunxian.Pelvis.ScreenPos = WorldToScreen(lunxian.Pelvis.Pos, lunxian.matrix, lunxian.camera);

/* 左肩膀 */
FTransform lshtrans = getBone(lunxian.Bone + 11 * 48);
FMatrix boneMatrix3 = TransformToMatrix(lshtrans);
lunxian.Left_Shoulder.Pos = MarixToVector(MatrixMulti(boneMatrix3, c2wMatrix));
lunxian.Left_Shoulder.ScreenPos = WorldToScreen(lunxian.Left_Shoulder.Pos, lunxian.matrix, lunxian.camera);

/* 右肩膀 */
FTransform rshtrans = getBone(lunxian.Bone + p * 48);
FMatrix boneMatrix4 = TransformToMatrix(rshtrans);
lunxian.Right_Shoulder.Pos = MarixToVector(MatrixMulti(boneMatrix4, c2wMatrix));
lunxian.Right_Shoulder.ScreenPos = WorldToScreen(lunxian.Right_Shoulder.Pos, lunxian.matrix, lunxian.camera);

/* 左手肘 */
FTransform lelbtrans = getBone(lunxian.Bone + 12 * 48);
FMatrix boneMatrix5 = TransformToMatrix(lelbtrans);
lunxian.Left_Elbow.Pos = MarixToVector(MatrixMulti(boneMatrix5, c2wMatrix));
lunxian.Left_Elbow.ScreenPos = WorldToScreen(lunxian.Left_Elbow.Pos, lunxian.matrix, lunxian.camera);

/* 右手肘 */
FTransform relbtrans = getBone(lunxian.Bone + o * 48);
FMatrix boneMatrix6 = TransformToMatrix(relbtrans);
lunxian.Right_Elbow.Pos = MarixToVector(MatrixMulti(boneMatrix6, c2wMatrix));
lunxian.Right_Elbow.ScreenPos = WorldToScreen(lunxian.Right_Elbow.Pos, lunxian.matrix, lunxian.camera);

/* 左手腕 */
FTransform lwtrans = getBone(lunxian.Bone + a * 48);
FMatrix boneMatrix7 = TransformToMatrix(lwtrans);
lunxian.Left_Wrist.Pos = MarixToVector(MatrixMulti(boneMatrix7, c2wMatrix));
lunxian.Left_Wrist.ScreenPos = WorldToScreen(lunxian.Left_Wrist.Pos, lunxian.matrix, lunxian.camera);

/* 右手腕 */
FTransform rwtrans = getBone(lunxian.Bone + b * 48);
FMatrix boneMatrix8 = TransformToMatrix(rwtrans);
lunxian.Right_Wrist.Pos = MarixToVector(MatrixMulti(boneMatrix8, c2wMatrix));
lunxian.Right_Wrist.ScreenPos = WorldToScreen(lunxian.Right_Wrist.Pos, lunxian.matrix, lunxian.camera);

/* 左大腿 */
FTransform Llshtrans = getBone(lunxian.Bone + c * 48);
FMatrix boneMatrix9 = TransformToMatrix(Llshtrans);
lunxian.Left_Thigh.Pos = MarixToVector(MatrixMulti(boneMatrix9, c2wMatrix));
lunxian.Left_Thigh.ScreenPos = WorldToScreen(lunxian.Left_Thigh.Pos, lunxian.matrix, lunxian.camera);

/* 右大腿 */
FTransform Lrshtrans = getBone(lunxian.Bone + d * 48);
FMatrix boneMatrix10 = TransformToMatrix(Lrshtrans);
lunxian.Right_Thigh.Pos = MarixToVector(MatrixMulti(boneMatrix10, c2wMatrix));
lunxian.Right_Thigh.ScreenPos = WorldToScreen(lunxian.Right_Thigh.Pos, lunxian.matrix, lunxian.camera);

/* 左膝盖 */
FTransform Llelbtrans = getBone(lunxian.Bone + e * 48);
FMatrix boneMatrix11 = TransformToMatrix(Llelbtrans);
lunxian.Left_Knee.Pos = MarixToVector(MatrixMulti(boneMatrix11, c2wMatrix));
lunxian.Left_Knee.ScreenPos = WorldToScreen(lunxian.Left_Knee.Pos, lunxian.matrix, lunxian.camera);

/* 右膝盖 */
FTransform Lrelbtrans = getBone(lunxian.Bone + f * 48);
FMatrix boneMatrix12 = TransformToMatrix(Lrelbtrans);
lunxian.Right_Knee.Pos = MarixToVector(MatrixMulti(boneMatrix12, c2wMatrix));
lunxian.Right_Knee.ScreenPos = WorldToScreen(lunxian.Right_Knee.Pos, lunxian.matrix, lunxian.camera);

/* 左脚腕 */
FTransform Llwtrans = getBone(lunxian.Bone + g * 48);
FMatrix boneMatrix13 = TransformToMatrix(Llwtrans);
lunxian.Left_Ankle.Pos = MarixToVector(MatrixMulti(boneMatrix13, c2wMatrix));
lunxian.Left_Ankle.ScreenPos = WorldToScreen(lunxian.Left_Ankle.Pos, lunxian.matrix, lunxian.camera);

/* 右脚腕 */
FTransform Lrwtrans = getBone(lunxian.Bone + h * 48);
FMatrix boneMatrix14 = TransformToMatrix(Lrwtrans);
lunxian.Right_Ankle.Pos = MarixToVector(MatrixMulti(boneMatrix14, c2wMatrix));
lunxian.Right_Ankle.ScreenPos = WorldToScreen(lunxian.Right_Ankle.Pos, lunxian.matrix, lunxian.camera);

float 距离限制;
if (lunxian.IsAiming == 1 || lunxian.IsAiming == 257)
距离限制 = NumIo[32];
else
距离限制 = NumIo[31];

if (DrawIo[20] && ((DrawIo[31] && !lunxian.IsBot) || !DrawIo[31]) && ((DrawIo[32] && lunxian.Health > 0) || !DrawIo[32]) && lunxian.Distance <= 距离限制) {
strcpy(Aim[AimCount].Name, lunxian.PlayerName);
Aim[AimCount].WodDistance = lunxian.Distance;
Aim[AimCount].AimMovement = lunxian.Predict;
if (NumIo[8] == 1.0){
Aim[AimCount].ObjAim = lunxian.Head.Pos;
Aim[AimCount].ScreenDistance = sqrt(pow(screen_x / 2 - lunxian.Head.ScreenPos.x, 2) + pow(screen_y / 2 - lunxian.Head.ScreenPos.y, 2));
} else if (NumIo[8] == 2.0){
Aim[AimCount].ObjAim = lunxian.Chest.Pos;
Aim[AimCount].ScreenDistance = sqrt(pow(screen_x / 2 - lunxian.Chest.ScreenPos.x, 2) + pow(screen_y / 2 - lunxian.Chest.ScreenPos.y, 2));
} else if (NumIo[8] == 3.0){
Aim[AimCount].ObjAim = lunxian.Pelvis.Pos; 
Aim[AimCount].ScreenDistance = sqrt(pow(screen_x / 2 - lunxian.Pelvis.ScreenPos.x, 2) + pow(screen_y / 2 - lunxian.Pelvis.ScreenPos.y, 2));
} else {
Aim[AimCount].ObjAim = lunxian.Head.Pos;
Aim[AimCount].ScreenDistance = sqrt(pow(screen_x / 2 - lunxian.Head.ScreenPos.x, 2) + pow(screen_y / 2 - lunxian.Head.ScreenPos.y, 2));
}  
AimCount++;
}

float top, right, left, bottom, top1; 

// 背敌
if (DrawIo[8]) {//敌背
    if(draw_style[2]==0){
        std::string ssd;
        ssd += "  队伍";
        ssd += to_string((int)lunxian.TeamID);
        ssd += "  \n  [";
        ssd += std::to_string((int) lunxian.Distance); 
        ssd += "米]";

        auto textSize = ImGui::CalcTextSize(ssd.c_str(), 0, 28);
        dx = 120.f/255.f;
        if (lunxian.Head.ScreenPos.x + lunxian.w < 0) {
            Draw->AddCircleFilled({40, lunxian.Head.ScreenPos.y}, 50, ImColor(arr[lunxian.TeamID%length]));    
            Draw->AddText(NULL, 28, {40 - (textSize.x / 2), lunxian.Head.ScreenPos.y - (textSize.y / 2)}, ImColor(255, 255, 255), ssd.c_str());                                      
        } else if (lunxian.w > 0 && lunxian.Head.ScreenPos.x > screen_x) {
            Draw->AddCircleFilled({screen_x - 40, lunxian.Head.ScreenPos.y}, 50, ImColor(arr[lunxian.TeamID%length]));                       
            Draw->AddText(NULL, 28, {screen_x - 40 - (textSize.x / 2), lunxian.Head.ScreenPos.y - (textSize.y / 2)}, ImColor(255, 255, 255), ssd.c_str());                                      
        } else if (lunxian.w > 0 && lunxian.Head.ScreenPos.y + lunxian.w < 0) {               
            Draw->AddCircleFilled({lunxian.Head.ScreenPos.x, 40}, 50, ImColor(arr[lunxian.TeamID%length]));     
            Draw->AddText(NULL, 28, {lunxian.Head.ScreenPos.x - (textSize.x / 2), 40 - (textSize.y / 2)}, ImColor(255, 255, 255), ssd.c_str());                                      
        } else if (lunxian.w < 0) {
            Draw->AddCircleFilled({screen_x - lunxian.Head.ScreenPos.x, screen_y - 40}, 50, ImColor(arr[lunxian.TeamID%length]));   
            Draw->AddText(NULL, 28, {screen_x - lunxian.Head.ScreenPos.x - (textSize.x / 2), screen_y - 40 - (textSize.y / 2)}, ImColor(255, 255, 255), ssd.c_str());                                      
        }
    }
    
    if(draw_style[2]==1){  
        dx = 120.f/255.f;
        float cameras = lunxian.matrix[3] * lunxian.Pos.x + lunxian.matrix[7] * lunxian.Pos.y + lunxian.matrix[11] * lunxian.Pos.z + lunxian.matrix[15]; 
        if (!lunxian.IsBot) {				
            OffScreen(lunxian.ScreenPos, cameras, ImColor(arr[lunxian.TeamID%length]), NumIo[3] + 20 + lunxian.Distance * 0.3);
        } else {
            OffScreen(lunxian.ScreenPos, cameras, ImColor(255, 255, 255, 255), NumIo[3] + 20 + lunxian.Distance * 0.3);
        }
    }
}

left  = lunxian.Head.ScreenPos.x - lunxian.w * 0.6;
right = lunxian.Head.ScreenPos.x + lunxian.w * 0.6;

if (!lunxian.Head.Pos.x) {
top1 = lunxian.Pelvis.ScreenPos.y - lunxian.Chest.ScreenPos.y;
} else {
top1 = lunxian.Pelvis.ScreenPos.y - lunxian.Head.ScreenPos.y;
}

top  = lunxian.Pelvis.ScreenPos.y - top1 - lunxian.w / 5;

if (lunxian.Left_Ankle.ScreenPos.y < lunxian.Right_Ankle.ScreenPos.y) {
bottom = lunxian.Right_Ankle.ScreenPos.y + lunxian.w / 10;
} else {
bottom = lunxian.Left_Ankle.ScreenPos.y  + lunxian.w / 10;
}

//方框
if (DrawIo[1]) {
    if (lunxian.IsBot) { 
        // 人机方框（默认白色）
        Draw->AddRect({left, top}, {right, bottom}, 绘制颜色[2], 0, 0, 绘制粗细[2]); 
        Draw->AddRectFilled({left, top}, {right, bottom}, 绘制颜色[4]); 
    } else {  
        // 初始化颜色和边框
        ImColor fillColor = ImColor(255, 255, 255, 50);  // 默认半透明白色
        ImColor borderColor = 绘制颜色[1];               // 默认边框颜色
        float borderThickness = 绘制粗细[1];            // 默认边框粗细

        // --- 优先级1: 特殊状态（倒地/开车） ---
        if (lunxian.敌方动作 == 524288 || lunxian.敌方动作 == 131072 || lunxian.敌方动作 == 524303) {
            // 倒地状态 - 黑色背景
            fillColor = ImColor(0, 0, 0, 80);
            borderColor = ImColor(0, 0, 0, 255);
            borderThickness = 2.0f;
        } else if (lunxian.敌方动作 == 12583952 || lunxian.敌方动作 == 12582928) {
            // 开车状态 - 黄色背景
            fillColor = ImColor(255, 255, 0, 60);
            borderColor = ImColor(255, 255, 0, 200);
            borderThickness = 2.0f;
        } 
        // --- 优先级2: 投掷动作（手雷倒计时） ---
        else if (lunxian.敌方动作 == 65552 or lunxian.敌方动作 == 69648 or lunxian.敌方动作 == 69664 or lunxian.敌方动作 == 65600 or lunxian.敌方动作 == 65681 or lunxian.敌方动作 == 65569 or lunxian.敌方动作 == 65601 or lunxian.敌方动作 == 65553 or lunxian.敌方动作 == 69649 or lunxian.敌方动作 ==17417 or lunxian.敌方动作 == 16401) {
               Draw->AddRectFilled({left, top}, {right, bottom}, ImColor(255,0,0,50));//背景颜色     填充色
Draw->AddRect({left, top}, {right, bottom}, ImColor(255, 0, 0, 255)); // 红色边框，不填充颜色
// 绘制7秒倒数文本
    static float countdown = 7.0f;
    static std::chrono::steady_clock::time_point lastTime = std::chrono::steady_clock::now();
    auto currentTime = std::chrono::steady_clock::now();
    std::chrono::duration<float> elapsedSeconds = currentTime - lastTime;

    if (elapsedSeconds.count() >= 1.0f) {
        countdown -= elapsedSeconds.count();
        lastTime = currentTime;
    }
        if (countdown > 0) {
        char buffer[32];
        sprintf(buffer, "%.1f", countdown);
        Draw->AddText({left + 10, top + 10}, ImColor(255, 255, 255, 255), buffer); // 白色文本
    } else {
        countdown = 7.0f; // 重置倒计时
    }
    }
        // --- 优先级3: 危险武器/手雷判断 ---
        else if (lunxian.scwq == 602003 || lunxian.scwq == 602004) { 
            // 手持手雷/燃烧瓶 - 亮红色
            fillColor = ImColor(255, 50, 50, 150);
            borderColor = ImColor(255, 0, 0, 255);
            borderThickness = 3.0f;
        } else if (
            (lunxian.scwq >= 103000 && lunxian.scwq < 104000) ||  // 狙击枪
            (lunxian.scwq >= 104000 && lunxian.scwq < 105000)     // 霰弹枪
        ) { 
            // 狙击枪/霰弹枪 - 浅红色
            fillColor = ImColor(255, 100, 100, 150);
            borderColor = ImColor(255, 100, 100, 200);
            borderThickness = 2.0f;
        }
        // --- 优先级4: 武器等级（破损/改进/精致等） ---
        else {
            int weaponID = lunxian.scwq;
            int suffix = weaponID % 10; // 取最后一位判断等级

            switch (suffix) {
                case 1: // 破损
                    fillColor = ImColor(128, 0, 0, 150);    // 暗红色
                    borderColor = ImColor(200, 0, 0, 200);
                    break;
                case 2: // 修复
                    fillColor = ImColor(255, 165, 0, 150);  // 橙色
                    borderColor = ImColor(255, 140, 0, 200);
                    break;
                case 3: // 完好
                    fillColor = ImColor(255, 255, 0, 150);  // 黄色
                    borderColor = ImColor(255, 215, 0, 200);
                    break;
                case 4: // 改进
                    fillColor = ImColor(0, 128, 0, 150);    // 绿色
                    borderColor = ImColor(50, 205, 50, 200);
                    break;
                case 5: // 精致
                    fillColor = ImColor(0, 0, 255, 150);    // 蓝色
                    borderColor = ImColor(30, 144, 255, 200);
                    break;
                case 6: // 卓越
                    fillColor = ImColor(128, 0, 128, 150);  // 紫色
                    borderColor = ImColor(147, 112, 219, 200);
                    break;
                default: // 无等级或未知
                    fillColor = ImColor(255, 255, 255, 50); 
                    borderColor = 绘制颜色[1];
                    break;
            }
        }

        // 绘制方框（填充+边框）
        Draw->AddRectFilled({left, top}, {right, bottom}, fillColor);
        Draw->AddRect({left, top}, {right, bottom}, borderColor, 0, 0, borderThickness);
    }
}

// 射线
if (DrawIo[2]) {
float 射线_y;
if (lunxian.IsBot) {
if (draw_style[0] == 0 || draw_style[0] == 1) 射线_y = 73; else if (draw_style[0] == 2) 射线_y = screen_y*0.135f;
Draw->AddLine({screen_x / 2 , 射线_y}, {lunxian.Head.ScreenPos.x, lunxian.Head.ScreenPos.y}, 绘制颜色[6], 绘制粗细[4]);  
} else {
Draw->AddLine({screen_x / 2 , 射线_y}, {lunxian.Head.ScreenPos.x, lunxian.Head.ScreenPos.y}, 绘制颜色[5], 绘制粗细[3]);  
}
}

ImColor 白色 = ImColor(255, 255, 255);
ImColor 红色 = ImColor(255,0,0, 255);
ImColor 绿色 = ImColor(0,250,250, 0);
// 骨骼
if (DrawIo[3]) {
Draw->AddCircle({lunxian.Head.ScreenPos.x, lunxian.Head.ScreenPos.y}, lunxian.w / 6, 绘制颜色[7], 100);
DrawBone({lunxian.Head.ScreenPos.x, lunxian.Head.ScreenPos.y}, {lunxian.Chest.ScreenPos.x, lunxian.Chest.ScreenPos.y});
DrawBone({lunxian.Chest.ScreenPos.x, lunxian.Chest.ScreenPos.y}, {lunxian.Pelvis.ScreenPos.x, lunxian.Pelvis.ScreenPos.y});
DrawBone({lunxian.Chest.ScreenPos.x, lunxian.Chest.ScreenPos.y}, {lunxian.Left_Shoulder.ScreenPos.x, lunxian.Left_Shoulder.ScreenPos.y});
DrawBone({lunxian.Chest.ScreenPos.x, lunxian.Chest.ScreenPos.y}, {lunxian.Right_Shoulder.ScreenPos.x, lunxian.Right_Shoulder.ScreenPos.y});
DrawBone({lunxian.Left_Shoulder.ScreenPos.x, lunxian.Left_Shoulder.ScreenPos.y}, {lunxian.Left_Elbow.ScreenPos.x, lunxian.Left_Elbow.ScreenPos.y});
DrawBone({lunxian.Right_Shoulder.ScreenPos.x, lunxian.Right_Shoulder.ScreenPos.y},{lunxian.Right_Elbow.ScreenPos.x, lunxian.Right_Elbow.ScreenPos.y});
DrawBone({lunxian.Left_Elbow.ScreenPos.x, lunxian.Left_Elbow.ScreenPos.y}, {lunxian.Left_Wrist.ScreenPos.x, lunxian.Left_Wrist.ScreenPos.y});
DrawBone({lunxian.Right_Elbow.ScreenPos.x, lunxian.Right_Elbow.ScreenPos.y}, {lunxian.Right_Wrist.ScreenPos.x, lunxian.Right_Wrist.ScreenPos.y});
DrawBone({lunxian.Pelvis.ScreenPos.x, lunxian.Pelvis.ScreenPos.y}, {lunxian.Left_Thigh.ScreenPos.x, lunxian.Left_Thigh.ScreenPos.y});
DrawBone({lunxian.Pelvis.ScreenPos.x, lunxian.Pelvis.ScreenPos.y}, {lunxian.Right_Thigh.ScreenPos.x, lunxian.Right_Thigh.ScreenPos.y});
DrawBone({lunxian.Left_Thigh.ScreenPos.x, lunxian.Left_Thigh.ScreenPos.y}, {lunxian.Left_Knee.ScreenPos.x, lunxian.Left_Knee.ScreenPos.y});
DrawBone({lunxian.Right_Thigh.ScreenPos.x, lunxian.Right_Thigh.ScreenPos.y}, {lunxian.Right_Knee.ScreenPos.x, lunxian.Right_Knee.ScreenPos.y});
DrawBone({lunxian.Left_Knee.ScreenPos.x, lunxian.Left_Knee.ScreenPos.y}, {lunxian.Left_Ankle.ScreenPos.x, lunxian.Left_Ankle.ScreenPos.y});
DrawBone({lunxian.Right_Knee.ScreenPos.x, lunxian.Right_Knee.ScreenPos.y}, {lunxian.Right_Ankle.ScreenPos.x, lunxian.Right_Ankle.ScreenPos.y});
}

if(DrawIo[9918]){
//绘制头部骨骼节点
Draw->AddCircleFilled({lunxian.Head.ScreenPos.x, lunxian.Head.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制左肩骨骼点
Draw->AddCircleFilled({lunxian.Left_Shoulder.ScreenPos.x, lunxian.Left_Shoulder.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制右肩骨骼点
Draw->AddCircleFilled({lunxian.Right_Shoulder.ScreenPos.x, lunxian.Right_Shoulder.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制左肘骨骼点
Draw->AddCircleFilled({lunxian.Left_Elbow.ScreenPos.x, lunxian.Left_Elbow.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制右肘骨骼点
Draw->AddCircleFilled({lunxian.Right_Elbow.ScreenPos.x, lunxian.Right_Elbow.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制左腕骨骼点
Draw->AddCircleFilled({lunxian.Left_Wrist.ScreenPos.x, lunxian.Left_Wrist.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制右腕骨骼点
Draw->AddCircleFilled({lunxian.Right_Wrist.ScreenPos.x, lunxian.Right_Wrist.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制左大腿骨骼点
Draw->AddCircleFilled({lunxian.Left_Thigh.ScreenPos.x, lunxian.Left_Thigh.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制右大腿骨骼点
Draw->AddCircleFilled({lunxian.Right_Thigh.ScreenPos.x, lunxian.Right_Thigh.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制左膝盖骨骼点
Draw->AddCircleFilled({lunxian.Left_Knee.ScreenPos.x, lunxian.Left_Knee.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制右膝盖骨骼点
Draw->AddCircleFilled({lunxian.Right_Knee.ScreenPos.x, lunxian.Right_Knee.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制左脚踝骨骼点
Draw->AddCircleFilled({lunxian.Left_Ankle.ScreenPos.x, lunxian.Left_Ankle.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制右脚踝骨骼点
Draw->AddCircleFilled({lunxian.Right_Ankle.ScreenPos.x, lunxian.Right_Ankle.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
}


// 血量&名字
if (DrawIo[6]) {
if (!lunxian.IsBot) {
DrawHealth({lunxian.Head.ScreenPos.x, top }, lunxian.w * 2, lunxian.Health, lunxian.TeamID, lunxian.PlayerName);
} else {
DrawHealth({lunxian.Head.ScreenPos.x, top }, lunxian.w * 2, lunxian.Health, lunxian.TeamID, "人机");
}
}


if(DrawIo[67]){//漏手模式专用
Draw->AddCircleFilled({lunxian.Head.ScreenPos.x, lunxian.Head.ScreenPos.y}, lunxian.w / 15,白色, 100);
}


// 距离
if (DrawIo[5]) {
string 距离 = to_string((int) lunxian.Distance);
距离 += " M";
auto textSize_距离 = ImGui::GetFont()->CalcTextSizeA((25), FLT_MAX, -1, 距离.c_str(), NULL, NULL);
DrawTf.绘制字体描边(25, lunxian.Pelvis.ScreenPos.x - textSize_距离.x/2, bottom + 15, ImVec4{1.0f, 1.0f, 1.0f, 1.0f},  距离.c_str());
// if(lunxian.Distance < 50){
// string str = "近点来人了";
        // auto textSize = ImGui::CalcTextSize(str.c_str(), 0, 25);            
        // ImGui::GetForegroundDrawList()->AddText(NULL,48,{screen_x / 2 - 99,200}, ImColor(255,0,0), str.c_str());
// }
}



//手持武器

// int  武器id;// 绘制手持图片请取消注释此行  4/7    PUBG同理也要删对应这几行
// 武器id = GetWeapon(lunxian.scwq);// 绘制手持图片请取消注释此行 5/7 PUBG同理也要删对应这几行

if (DrawIo[10])
{
  string s;
  s += GetHol(lunxian.scwq);
  s += " ";
  s += to_string((int)lunxian.dqzd);
  s += "/";
  s += to_string((int)lunxian.zdmax);
  auto textSize = ImGui::GetFont()->CalcTextSizeA(25, FLT_MAX, -1, s.c_str(), NULL, NULL); 
  ImGui::GetForegroundDrawList()->AddText(NULL, 25.f, { lunxian.Head.ScreenPos.x - (textSize.x / 2), top - 45 - (textSize.y / 2) }, ImColor(255,255,255,255), s.c_str());
  PlayerId = lunxian.scwq;

// float png_y = (DrawIo[10] == true) ? 45 : 0; // 绘制手持图片请取消注释此行  6/7 
// ImGui::GetForegroundDrawList()->AddImage(weapon[武器id/10], {lunxian.Head.ScreenPos.x - 60, top - 80 - png_y}, {lunxian.Head.ScreenPos.x + 60, top - 40 - png_y}); // 绘制手持图片请取消注释此行 7/7
}







} //人物绘制结束


if (wz.w > 0){
// 内鬼绘制
if (wzhz[21]) { // 绘制开关
    if ((strstr(wz.Name, "_PlayerPawn_Impostors_C") != 0) || 
        (strstr(wz.Name, "BP_PlayerPawn_Impo") != 0)) 
    {
        std::string name = "内鬼[";
        name += std::to_string((int)wz.Distance);
        name += "米]";
        
        // 计算文本尺寸
        auto textSize = ImGui::CalcTextSize(name.c_str(), 0, 30);
        
        // 坐标计算
        float r_x = wz.ScreenPos.x;
        float r_y = wz.ScreenPos.y - 15; // 上移15像素避免重叠
        
        // 红色文本绘制
        Draw->AddText(
            NULL, 
            30,  // 保持示例的30号字体
            {r_x - (textSize.x / 2), r_y}, 
            ImColor(255, 0, 0, 255), 
            name.c_str()
        );
    }
}
if (wzhz[11]) {
string name;
name += "宝箱[" + to_string((int)wz.Distance) + "米]\n";
if (strstr(wz.Name, "EscapeBoxHight_SupplyBox_Lv5_C") || strstr(wz.Name, "Escape_SupplyBax_Lv5_C") || strstr(wz.Name, "EscapeBoxHight_SupplyBox_Lv4_C") || strstr(wz.Name, "Escape_SupplyBax_Lv4_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 0,0, 255), name.c_str());
}
}
  
if (wzhz[12]&&BOOS(wz.Name, &CasName)) { //地铁BOOS
string name;
name += CasName;
if(wz.Distance<400){
name += "[";
name += to_string((int)wz.Distance);
name += "米]";
auto textSize = ImGui::CalcTextSize(name.c_str(),0, 30);
Draw->AddText(NULL, 20,{wz.ScreenPos.x-(textSize.x / 2), wz.ScreenPos.y}, ImColor(255,255,0,255), name.c_str());  
  }
  }
// 超级物资箱
if (wzhz[10]) {
string name;
name += "超级物资箱！[" + to_string((int)wz.Distance) + "米]\n";
if (strstr(wz.Name, "MilitarySupplyBoxBase_Baltic_Classic_C") || strstr(wz.Name, "EscapeBox_SpeEffect_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 0,0, 255), name.c_str());
}
}

//召回信号枪
if (wzhz[9]) {
string name;

name += "召回信号枪[" + to_string((int)wz.Distance) + "米]\n";

if (strstr(wz.Name, "BP_Pistol_RevivalFlaregun_C") || strstr(wz.Name, "BP_Pistol_RevivalFlaregun_Wrapper_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name.c_str());
}
}

//自救器
if (wzhz[8]) {
string name;

name += "自救器[" + to_string((int)wz.Distance) + "米]\n";

if (strstr(wz.Name, "_revivalAED_Pickup_C") || strstr(wz.Name, "BP_Pickup_Finger_C")) {//加了个飞索
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name.c_str());
}
}

//针
if (wzhz[7]) {
string name;

name += "肾上腺素[" + to_string((int)wz.Distance) + "米]\n";

if (strstr(wz.Name, "jection_Pickup_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name.c_str());
}
}
//载具绘制 和平和PUBG
if (wzhz[1]) {
string name;
string name1;
string name2;
string name3;
string name4;
string name5;
string name6;
string name7;
string name8;
string name9;
string name10;
string name11;
string name12;
string name13;
string name14;
string name15;
string name16;
string name17;
string name18;
string name19;
string name20;
string name21;
string name22;
string name23;
string name24;
string name25;
string name26;
string name27;
string name28;
string name29;
string name30;
string name31;
string name32;
string name33;
string name34;
string name35;
string name36;
string name37;//PUBG
string name38;//PUBG
string name39;//PUBG
string name40;//PUBG


name += "蹦蹦[" + to_string((int)wz.Distance) + "米]\n";
name1 += "吉普[" + to_string((int)wz.Distance) + "米]\n";
name2 += "摩托车[" + to_string((int)wz.Distance) + "米]\n";
name3 += "三轮摩托车[" + to_string((int)wz.Distance) + "米]\n";
name4 += "轿车[" + to_string((int)wz.Distance) + "米]\n";
name5 += "冲锋艇[" + to_string((int)wz.Distance) + "米]\n";
name6 += "快艇[" + to_string((int)wz.Distance) + "米]\n";
name7 += "巴士[" + to_string((int)wz.Distance) + "米]\n";
name8 += "双人跑车[" + to_string((int)wz.Distance) + "米]\n";
name9 += "小绵羊[" + to_string((int)wz.Distance) + "米]\n";
name10 += "尼罗皮卡[" + to_string((int)wz.Distance) + "米]\n";
name11 += "轻型雪地车[" + to_string((int)wz.Distance) + "米]\n";
name12 += "重型雪地车[" + to_string((int)wz.Distance) + "米]\n";
name13 += "三蹦子[" + to_string((int)wz.Distance) + "米]\n";
name14 += "装甲车[" + to_string((int)wz.Distance) + "米]\n";
name15 += "雪地越野[" + to_string((int)wz.Distance) + "米]\n";
name16 += "大脚车[" + to_string((int)wz.Distance) + "米]\n";
name17 += "滑翔机[" + to_string((int)wz.Distance) + "米]\n";
name18 += "肌肉跑车[" + to_string((int)wz.Distance) + "米]\n";
name19 += "山地摩托[" + to_string((int)wz.Distance) + "米]\n";
name20 += "电动车[" + to_string((int)wz.Distance) + "米]\n";
name21 += "敞篷跑车[" + to_string((int)wz.Distance) + "米]\n";
name22 += "马[" + to_string((int)wz.Distance) + "米]\n";
name23 += "马[" + to_string((int)wz.Distance) + "米]\n";
name24 += "马[" + to_string((int)wz.Distance) + "米]\n";
name25 += "马[" + to_string((int)wz.Distance) + "米]\n";
name26 += "拉力赛车[" + to_string((int)wz.Distance) + "米]\n";
name27 += "沙漠大脚车[" + to_string((int)wz.Distance) + "米]\n";
name28 += "敞篷肌肉跑车[" + to_string((int)wz.Distance) + "米]\n";
name29 += "旅行车[" + to_string((int)wz.Distance) + "米]\n";
name30 += "宝宝巴士[" + to_string((int)wz.Distance) + "米]\n";
name31 += "布朗suv[" + to_string((int)wz.Distance) + "米]\n";
name32 += "地铁矿车[" + to_string((int)wz.Distance) + "米]\n";
name33 += "蹦子炮车[" + to_string((int)wz.Distance) + "米]\n";
name34 += "渣土车[" + to_string((int)wz.Distance) + "米]\n";
name35 += "挖机[" + to_string((int)wz.Distance) + "米]\n";
name36 += "自行车[" + to_string((int)wz.Distance) + "米]\n";
name37 += "低级坦克 BOSS[" + to_string((int)wz.Distance) + "米]\n";
name38 += "高级坦克丨商店[" + to_string((int)wz.Distance) + "米]\n";//你妈逼我英语不好？store是商店你跟我说是坦克？
name39 += "地铁矿车[" + to_string((int)wz.Distance) + "米]\n";
name40 += "地铁坦克[" + to_string((int)wz.Distance) + "米]\n";


if (strstr(wz.Name, "Buggy")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name.c_str());
} else if (strstr(wz.Name, "UAZ")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name1.c_str());
} else if (strstr(wz.Name, "Motorcycle")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name2.c_str());
} else if (strstr(wz.Name, "MotorcycleC")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name3.c_str());
} else if (strstr(wz.Name, "Dacia")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name4.c_str());
} else if (strstr(wz.Name, "AquaRail")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name5.c_str());
} else if (strstr(wz.Name, "PG117")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name6.c_str());
} else if (strstr(wz.Name, "MiniBus")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name7.c_str());
} else if (strstr(wz.Name, "VH_CoupeRB_1_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name8.c_str());
} else if (strstr(wz.Name, "Scooter")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name9.c_str());
} else if (strstr(wz.Name, "Rony")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name10.c_str());
} else if (strstr(wz.Name, "Snowbike")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name11.c_str());
} else if (strstr(wz.Name, "Snowmobile")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name12.c_str());
} else if (strstr(wz.Name, "Tuk")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name13.c_str());
} else if (strstr(wz.Name, "BRDM")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name14.c_str());
} else if (strstr(wz.Name, "LadaNiva")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name15.c_str());
} else if (strstr(wz.Name, "Bigfoot")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name16.c_str());
} else if (strstr(wz.Name, "Motorglider")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name17.c_str());
} else if (strstr(wz.Name, "rado_close_1_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name18.c_str());
} else if (strstr(wz.Name, "ATV")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name19.c_str());
} else if (strstr(wz.Name, "Scooter")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name20.c_str());
} else if (strstr(wz.Name, "VH_4SportCar_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name21.c_str());
} else if (strstr(wz.Name, "VH_Horse_1_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name22.c_str());
} else if (strstr(wz.Name, "VH_Horse_4_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name23.c_str());
} else if (strstr(wz.Name, "VH_Horse_3_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name24.c_str());
} else if (strstr(wz.Name, "VH_Horse_2_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name25.c_str());
} else if (strstr(wz.Name, "VH_Drift_001_New_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name26.c_str());
} else if (strstr(wz.Name, "VH_DesertCar_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name27.c_str());
} else if (strstr(wz.Name, "Mirado")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name28.c_str());
} else if (strstr(wz.Name, "StationWagon")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name29.c_str());
} else if (strstr(wz.Name, "VH_Picobus_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name30.c_str());
} else if (strstr(wz.Name, "VH_Blanc_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name31.c_str());
} else if (strstr(wz.Name, "TrackVehicle_BP_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name32.c_str());
} else if (strstr(wz.Name, "VH_LostMobile_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name33.c_str());
} else if (strstr(wz.Name, "VH_DumpTruck_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name34.c_str());
} else if (strstr(wz.Name, "MH_Excavator_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name35.c_str());
} else if (strstr(wz.Name, "VH_Mountainbike_Training_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name36.c_str());
} else if (strstr(wz.Name, "AIVH_Leopard_1A3_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name37.c_str());
} else if (strstr(wz.Name, "ClassicStore")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name38.c_str());
} else if (strstr(wz.Name, "TrackVehicle_BP_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name39.c_str());
} else if (strstr(wz.Name, "AIVH_Weapon_Turret_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name40.c_str());
ImGui::GetBackgroundDrawList()->AddRect({wz.ScreenPos.x - 46, wz.ScreenPos.y + 10}, {wz.ScreenPos.x + 96, wz.ScreenPos.y + 23}, ImColor(100,149,237), cornerRadius);
}
}
//头甲倍镜
if (wzhz[6]) {
string name;

name += "高倍镜[" + to_string((int)wz.Distance) + "米]\n";

if (strstr(wz.Name, "MZJ_6X_Pickup_C") || strstr(wz.Name, "MZJ_4X_Pickup_C") || strstr(wz.Name, "MZJ_3X_Pickup_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name.c_str());
}
}

//饮料止痛药医疗箱
if (wzhz[5]) {
string name;

name += "高级药品[" + to_string((int)wz.Distance) + "米]\n";

if (strstr(wz.Name, "lls_Pickup_C") || strstr(wz.Name, "ink_Pickup_C") || strstr(wz.Name, "rstAidbox_Pickup_C")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name.c_str());
}
}

//金插绘制
if (wzhz[4]) {
string name;

name += "金插[" + to_string((int)wz.Distance) + "米]\n";

if (strstr(wz.Name, "perPeopleSkill")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name.c_str());
}

}

//信号枪绘制
if (wzhz[3]) {
string name;
name += "信号枪[" + to_string((int)wz.Distance) + "米]\n";
if (strstr(wz.Name, "BP_Pistol_Flaregun_Wrapper_C") || strstr(wz.Name, "Flare")) {
    Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 255), name.c_str());
}
}




/*


if (DrawIo[70]&&chaoji(wz.Name, &CasName)) { //超级物资箱
string name;
name += CasName;
if(wz.Distance<50){
name += "[";
name += to_string((int)wz.Distance);
name += "米]";
auto textSize = ImGui::CalcTextSize(name.c_str(),0, 30);
Draw->AddText(NULL, 20,{wz.ScreenPos.x-(textSize.x / 2), wz.ScreenPos.y}, ImColor(255,0,0,255), name.c_str());  
  }
  }

*/
// 优化后的宝箱绘制逻辑（直接通过名称关键字判断）
if (DrawIo[910] && 
    (strstr(wz.Name, "EscapeBoxHight_SupplyBox_") != nullptr ||   // 匹配常规宝箱
     strstr(wz.Name, "EscapeBox_SupplyBox_") != nullptr))    // 匹配可能的拼写变体
{
    // 合并条件判断：状态+距离
    if (const int 宝箱状态 = driver->read<int>(lunxian.Objaddr + 0x270);
        宝箱状态 == 0 && wz.Distance >= 0.5f) 
    {
        // 文本构造
        std::string goods = "[未开启]宝箱[" + std::to_string(static_cast<int>(wz.Distance)) + "米]";

        // 计算绘制参数
        const ImVec2 textSize = ImGui::CalcTextSize(goods.c_str());
        const ImVec2 basePos = { wz.ScreenPos.x - (textSize.x * 0.5f), wz.ScreenPos.y };

        // 带背景的文字绘制
        Draw->AddRectFilled(
            { basePos.x - 5, basePos.y - 3 },
            { basePos.x + textSize.x + 5, basePos.y + textSize.y + 3 },
            ImColor(30, 30, 30, 220),  // 深色半透明背景
            cornerRadius
        );
        Draw->AddText(
            nullptr,
            25.0f,
            basePos,
            (宝箱状态 == 0) ? ImColor(255, 215, 0) : ImColor(128, 128, 128), // 金色/灰色
            goods.c_str()
        );
    }
}

if (wzhz[2]) {
    if(!(wz.w < 0 || wz.w > screen_x)){
        if (lunxian.Distance < 2000.0f) {
            std::string WzClassName = GetClssName(lunxian.Objaddr);
            //匹配物资名字
            std::string_view WzName_view = reader.getValue(WzClassName);
            //如果字符串WzName_view不为空
            if (!WzName_view.empty()) {
                //转换WzName_view为std::string
                std::string WzName(WzName_view.begin(), WzName_view.end());
                char WzName_Distance[64];
                std::string formatted = std::string("%s[") + std::to_string((int)wz.Distance) + "米]";
                sprintf(WzName_Distance, formatted.c_str(), WzName.c_str());
                Draw->AddText(NULL,23, ImVec2(wz.ScreenPos.x, wz.ScreenPos.y),ImColor(255,215,0), WzName_Distance);
            }
        }
    }
}
if (DrawIo[14]) {
string name;
string name1;
string name2;
name += "手榴弹[" + to_string((int)wz.Distance) + "米]\n";
name1 += "燃烧瓶[" + to_string((int)wz.Distance) + "米]\n";
name2 += "烟雾弹[" + to_string((int)wz.Distance) + "米]\n";
if (strstr(wz.Name, "ProjGrenade_BP_C") || strstr(wz.Name, "BP_Grenade_Shoulei_C")) {
Draw->AddText(NULL, 20, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 0, 0), name.c_str());
Draw->AddCircle({ wz.ScreenPos.x, wz.ScreenPos.y }, 45.0f, ImColor(255, 0, 0), 12);
} else if (strstr(wz.Name, "BP_Grenade_Burn_C") || strstr(wz.Name, "ProjBurn_BP_C")) {
Draw->AddText(NULL, 20, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 0), name1.c_str());
Draw->AddCircle({ wz.ScreenPos.x, wz.ScreenPos.y }, 45.0f, ImColor(255, 0, 0), 12);
} else if (strstr(wz.Name, "BP_Grenade_Smoke_C")) {
Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(0, 255, 0), name2.c_str());
Draw->AddCircle({ wz.ScreenPos.x, wz.ScreenPos.y }, 45.0f, ImColor(0, 255, 0), 12);
}


if (strstr(wz.Name, "BP_Grenade_Shoulei_C") || strstr(wz.Name, "BP_Grenade_Burn_C")) {
if (wz.Distance < 100) {
// 在屏幕中间绘制一个附近有手雷的文本
string guistr = "附近有投掷物";
Draw->AddText(NULL, 70, {screen_x/2 -160, 35 + (110 - 35)/2}, ImColor(255, 0, 0), guistr.c_str());
}
}
}
}




} //总循环
MaxPlayerCount = AimCount;
lunxian.TotalUp = lunxian.PlayerCount + lunxian.BotCount;
