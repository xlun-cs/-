Uworld = driver->read<uintptr_t>(libUE4 + 0x12161358);
        usleep(NumIo[32]);
        
        if (Uworld == 0) {
            continue;
        }

        Uleve = driver->read<uintptr_t>(Uworld + ULEVE_OFFSET) + A0_OFFSET;
        Arrayaddr = driver->read<uintptr_t>(Uleve);
        Count = driver->read<int>(Uleve + COUNT_OFFSET);

        if (Count <= 0 || Count > 2000) {
            continue;
        }

	uintptr_t MatrixAddr = driver->read<uintptr_t>(libUE4 + 0X12132D60);
	
    Matrix = driver->read<uintptr_t>(MatrixAddr + 0x20) + 0x270;

		
		oneself = driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(Uworld + 0x98) + 0x88) + 0x30) + 0x32a8);
	
		MyTeam = getMyTeam(oneself);	
		
	    TempRead.MyWeapon = driver->read<int>(driver->read<uintptr_t>(driver->read<uintptr_t>(oneself + 0x3190) + 0x678) + 0xbd0);
		driver->read(driver->read<uintptr_t>(oneself + 0x278) + 0x200, &TempRead.MyPos, 12);				
		
		
		driver->read(Matrix, &matrix, 16 * 4);	
		driver->read(Matrix, &TempRead.matrix, 16 * 4);
		
		// 获取自身对象的地址 fov
uintptr_t selfAddress = oneself + 0x5588;
// 获取视野值的地址
uintptr_t fovAddress = driver->read<uintptr_t>(driver->read<uintptr_t>(selfAddress) + 0x608) + 0x630;
// 从地址中读取视野值
std::unique_ptr<float> fovValuePtr = std::make_unique<float>(driver->read<float>(fovAddress));

// 如果需要使用视野值，可以通过 fovValuePtr->get() 来获取
if (fovValuePtr) {
    TempRead.Fov = *fovValuePtr;
}

// 当不再需要时，fovValuePtr 会在作用域结束时自动释放资源

			TempRead.IsAiming = driver->read<int>(oneself + 0x1660);
        TempRead.IsFiring = driver->read<int>(oneself + 0x23e0);	
        
        
        
        
        
	for (int i = 0; i < Count; i ++)
		{		
			Objaddr = driver->read<uintptr_t>(Arrayaddr + 8 * i);  // 遍历数量次数
			
			if (Objaddr == 0 || Objaddr <= 0x10000000 || Objaddr % 4 != 0 || Objaddr >= 0x10000000000)
            	continue;		
			uintptr_t object = driver->read<uintptr_t>(Objaddr + 0x278);
			
		if (object <= 0xffff || object == 0 || object <= 0x10000000 || object % 4 != 0 || object >= 0x10000000000)
            	continue;
				
			
	
			
			if ((DrawIo[11] || DrawIo[12] || DrawIo[14] || DrawIo[71] || DrawIo[74] || DrawIo[73] || DrawIo[75] || DrawIo[98])&&driver->read<float>(Objaddr + 0x3518) != 479.5) {
			GetClassName(Name, driver->read<uintptr_t>(libUE4 + 0x10BE9988), driver->read<int>(Objaddr + 0x18));//gname
			uintptr_t Object = driver->read<uintptr_t>(Objaddr + 0x278);
			auto *wuzis = &TempRead.mwuziArray.mwuzi[AddrCount1];
			
			driver->read(object + 0x200, &wuzis->Pos, 12);
			if (wuzis->Pos.x == 0 || wuzis->Pos.y == 0 || wuzis->Pos.z == 0) {
         		continue;
     		}
     		
     		
     		GetDistance(wuzis->Pos, TempRead.MyPos, &wuzis->Distance);
			WorldToScreen(&wuzis->ScreenPos, &camera, &wuzis->w, wuzis->Pos);			
			wuzis->camera = camera;
			strcpy(wuzis->wuziName,Name);
			AddrCount1++;
			}
			
			
		
		
					
			if (driver->read<float>(Objaddr + 0x3518) != 479.5) {
				continue;
			}
			
			if (object <= 0xffff || object == 0 || object <= 0x10000000 || object % 4 != 0 || object >= 0x10000000000)
            	continue;
				
			auto *Players = &TempRead.mPlayerArray.mPlayer[AddrCount];
			
			driver->read(object + 0x200, &Players->Pos, 12);
			if (Players->Pos.x == 0 || Players->Pos.y == 0 || Players->Pos.x == 0) {
         		continue;
     		}
     		
     		
     		
			
		/*	int State = driver->read<int>(Objaddr + 0x1368);
        	if (State == 1048576 || State == 1048592)
           		continue;*/
        
        	Players->TeamID = driver->read<int>(Objaddr + 0xac0);
        	if (Players->TeamID == MyTeam/* || Players->TeamID < 1*/)
            	continue;
            
        	float MinHealth = driver->read<float>(Objaddr + 0xEd8);
        	float MaxHealth = driver->read<float>(Objaddr + 0xEe0);
        	Players->Health = (MinHealth / MaxHealth) * 100;
        	if (Players->Health > 100)
            continue;
            
            MyState = driver->read<uintptr_t>(oneself + 0x1538);
            
           MyWeapon = driver->read<int>(driver->read<uintptr_t>(driver->read<uintptr_t>(Objaddr + 0x3190) + 0x678) + 0xbd0);

 
Players->scwq = driver->read<int>(driver->read<uintptr_t>(driver->read<uintptr_t>(Objaddr + 0x3190) + 0x678) + 0xbd0);
	Players->dqzd = driver->read<int>(driver->read<uintptr_t>(driver->read<uintptr_t>(Objaddr + 0x3190) + 0x678) + 0x19e0);
		Players->zdmax = driver->read<int>(driver->read<uintptr_t>(driver->read<uintptr_t>(Objaddr + 0x3190) + 0x678) + 0x19e4);


 Players->Dzid = driver->read<int>(driver->read<uintptr_t>(Objaddr + 0x1538));//状态


    if (driver->read<uintptr_t>(Objaddr + 0x1000)) {
            	driver->read(driver->read<uintptr_t>(Objaddr + 0x1000) + 0x170, &Players->Predict, sizeof(Players->Predict)); // 载具向量

      	 	} else {
            	driver->read(Objaddr + 0xfdc, &Players->Predict, sizeof(Players->Predict)); // 敌人向量
        	}      

    GetDistance(Players->Pos, TempRead.MyPos, &Players->Distance);
    WorldToScreen(&Players->ScreenPos, &camera, &Players->w, Players->Pos);

    Players->camera = camera;

    Players->IsBot = driver->read<int>(Objaddr + 0xABc);

    	/*
			if(DrawIo[17])
            {
           // 是否为人机
            if (driver->read<int>(Objaddr + 0x9dc)&&MaxHealth<=1000)
            {
             continue;
            }
            
         }
			if(DrawIo[38])
			{
			
			if (driver->read<int>(Objaddr + 0x9dc)&&MaxHealth>=1000)
            {
             continue;
            }
			
			
			}
			*/

    getUTF8(Players->PlayerName, driver->read<uintptr_t>(Objaddr + 0xA40));

   
   
   
			
		Mesh = driver->read<uintptr_t>(Objaddr + 0x600);
		
                int Bonecount = driver->read<int>(Mesh + 0x7f8);   // + 0x30;

                if (Mesh <= 0xffff)
                    continue;

                Human = Mesh + 0x1f0;
                if (Human <= 0xffff)
                    continue;

      Bone = driver->read<uintptr_t>(Mesh + 0x7f8)+0x30;
