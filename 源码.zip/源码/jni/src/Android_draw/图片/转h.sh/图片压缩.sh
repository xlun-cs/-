#!/bin/bash

blue="\033[1;34m"
reset="\033[0m"

# 手动输入图片路径和输出文件路径
echo -e "${blue}请输入图片路径${reset}"
read input_image

echo -e "\033[1;32m请输入输出路径\033[0m"
read output_path

# 检查输入图片是否存在
if [ ! -f "$input_image" ]; then
    echo -e "\033[1;31m错误：图片 '$input_image' 不存在。\033[1;31m"
    exit 1
fi

# 检查optipng是否安装
if ! command -v optipng &>/dev/null; then
    echo -e "\033[1;31m错误：需要安装optipng，使用以下命令安装：\nsudo apt install optipng\033[0m"
    exit 1
fi

# 创建临时文件
temp_image=$(mktemp --suffix=.png)

# 使用optipng进行最高级别压缩
echo -e "${blue}正在进行最高级别图片压缩...${reset}"
if ! optipng -o7 -out "$temp_image" "$input_image"; then
    echo -e "\033[1;31m错误：图片压缩失败\033[0m"
    rm -f "$temp_image"
    exit 1
fi

# 从压缩后的图片读取二进制数据
binary_data=$(xxd -i -c 16 "$temp_image")

# 清理临时文件
rm -f "$temp_image"

# 手动输入变量名称
echo -e "\033[1;33m请输入变量名称(例如:image_data):\033[0m"
read variable_name

# 生成输出文件名
output_file=$(basename "$input_image" .png).h

# 确保输出路径以斜杠结尾
output_path="${output_path%/}/"

# 创建完整输出路径
mkdir -p "$output_path"
output_header="${output_path}${output_file}"

# 编写C头文件内容
header_content="// 自动生成的图像头文件（使用OptiPNG最高压缩级别）
unsigned char $variable_name[] = {
$binary_data
};

"

# 写入输出文件
echo "$header_content" > "$output_header"
echo -e "\033[1;36m处理完成：压缩后的头文件已保存至 $output_header\033[0m"
