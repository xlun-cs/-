#!/bin/bash

blue="\033[1;34m"
reset="\033[0m"

echo -e "${blue}请输入图片路径${reset}"
read input_image

echo -e "\033[1;32m请输入输出路径\033[0m"
read output_path

if [ ! -f "$input_image" ]; then
    echo -e "\033[1;31m错误：图片 '$input_image' 不存在。\033[0m"
    exit 1
fi

# 关键优化点：增大每行字节数 + 压缩逗号空格 + 移除长度变量
binary_data=$(xxd -i -c 32 "$input_image" | sed 's/, /,/g' | grep -v 'unsigned int')

echo -e "\033[1;33m请输入变量名称(例如:image_data):\033[0m"
read variable_name

output_file=$(basename "$input_image" .png)
if [[ "$output_file" != *".h" ]]; then
    output_file="$output_file.h"
fi

output_header="${output_path}"

# 使用紧凑格式写入头文件
header_content="unsigned char $variable_name[] = {
$binary_data
};"

echo "$header_content" > "$output_header"
echo -e "\033[1;36m处理完成\033[0m"
