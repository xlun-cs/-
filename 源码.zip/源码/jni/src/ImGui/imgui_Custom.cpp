#include "imgui_Custom.h"

#include <unordered_map>

namespace fidenBoard {
    // Implement the Size constructor
    Size::Size(int width, int height) : width(width), height(height) {}

    // Implement InputText methods
    void InputText::setText(std::string val) { text = val; }
    std::string InputText::getText() { return text; }
    std::string* InputText::getAddress() { return &text; }
    InputText inputText;

    Properties::Properties(ImVec2 size, flags flag) : flag(flag), size(size.x, size.y) {}
    flags Properties::getFlags() { return flag; }
    void Properties::setFlags(flags flag) { this->flag = flag; }

    // Implement Lines methods
    Lines::Lines() {
        lines[0] = "qwertyuiop";
        lines[1] = "asdfghjkl";
        lines[2] = "zxcvbnm";
    }

    void Lines::toCaps(bool caps) {
        for (int i = 0; i < getSize(); i++) {
            std::string* str = &lines[i];
            for (int p = 0; p < lines[i].size(); p++) {
                char* r = &lines[i][p];
                if (caps) {
                    *r = toupper(*r);
                }
                else {
                    *r = tolower(*r);
                }
            }
        }
    }
	
    int Lines::getSize() { return sizeof lines / sizeof lines[0]; }
    Lines linez;
    namespace specialChars {
        bool isCaps = false; // Initialize isCaps

        void Canc::add(float width,float height) {
            if (ImGui::Button("删除", { width,height })) {
                std::string res;
                if (inputText.getText().size() == 0) { return; }
                for (int i = 0; i < (inputText.getText().size() - 1); i++) {
                    res += inputText.getText()[i];
                }
                *inputText.getAddress() = res;
            }
        }

        void Caps::add(float width,float height) {
            if (ImGui::Button("大写", { width,height})) {
                isCaps = !isCaps;
                for (int i = 0; i < linez.getSize(); i++) {
                    std::string* str = &linez.lines[i];
                    for (int p = 0; p < linez.lines[i].size(); p++) {
                        char* r = &linez.lines[i][p];
                        if (isCaps) {
                            *r = toupper(*r);
                        }
                        else {
                            *r = tolower(*r);
                        }
                    }
                }
            }
        }

        void Space::add() {
            if (ImGui::Button("空格", {ImGui::GetWindowWidth(), (ImGui::GetWindowHeight() / 10)})) {
                *inputText.getAddress() += ' ';
            }
        }
    }

    void FidenBoard::addKeyword(std::string carattere, float width, float height) {
        if (ImGui::Button(carattere.c_str(), {width, height})) {
            *inputText.getAddress() += carattere;
        }
        ImGui::SameLine();
    }
    void FidenBoard::addKeywordSameLine(std::string str, int width, int height) {
        for (int i = 0; i < str.size(); i++) {
            std::string charTostring(1, str[i]);
            addKeyword(charTostring, width,height);
        }
        ImGui::Text("");
    }
    std::string FidenBoard::getInputText() {
        return inputText.getText();
    }
    void FidenBoard::setInputText(std::string val) {
        inputText.setText(val);
    }
    FidenBoard::FidenBoard(ImVec2 size, flags flag) {
        properties = new Properties(size, flag);
        float startX = (ImGui::GetWindowWidth() - 10 * 100 - 20) * 0.5f;
        ImGui::SetCursorPosX(startX);
        addKeywordSameLine("1234567890");
        ImGui::SetCursorPosX(startX);
        addKeywordSameLine(linez.lines[0]);
        startX = (ImGui::GetWindowWidth() - 9 * 100 - 20) * 0.5f;
        ImGui::SetCursorPosX(startX);
        addKeywordSameLine(linez.lines[1]);
        startX = (ImGui::GetWindowWidth() - 10 * 100 + 15 - 20) * 0.5f;
        ImGui::SetCursorPosX(startX);
        caps.add(120);
        ImGui::SameLine();
        addKeywordSameLine(linez.lines[2]);
        ImGui::SameLine(9 * 100 + 20);
        canc.add(120);
    }
}






/*
bool ImGui::M_SwitchButton(const char* str_id, bool* v, const ImVec2& size) {
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(str_id);
    ImVec4* colors = GetStyle().Colors;
    ImVec2 pos = window->DC.CursorPos;
    ImDrawList* draw_list = GetWindowDrawList();

    const float gui_height = GetFrameHeight();
    const ImVec2 label_size = CalcTextSize(str_id, NULL, true);
    float width = gui_height * size.x;
    float height = gui_height * size.y;
    const ImRect total_bb(pos, ImVec2(pos.x + (width * 1.15f) + (label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f), pos.y + label_size.y + style.FramePadding.y * 2.0f));
    ItemSize(total_bb, style.FramePadding.y);
    if (!ItemAdd(total_bb, id))
        return false;

    static std::unordered_map<ImGuiID, float> anim_times;
    static std::unordered_map<ImGuiID, bool> button_states;
    const float anim_speed = 0.45f; // 控制动画速度的常量

    bool hovered, held;
    bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);
    if (pressed) {
        *v = !(*v);
        MarkItemEdited(id);
        anim_times[id] = 0.0f; // 重置动画时间
        button_states[id] = *v; // 更新按钮状态
    }

    // 初始化动画时间和按钮状态
    if (anim_times.find(id) == anim_times.end()) {
        anim_times[id] = 0.0f; // 开始时没有延迟
        button_states[id] = *v;
    }

    anim_times[id] += g.IO.DeltaTime;
    anim_times[id] = ImMin(anim_times[id], anim_speed); // 限制动画时间

    float t = anim_times[id] / anim_speed;
    bool current_state = button_states[id];
    if (current_state)
        t = 1.0f - (1.0f - t) * (1.0f - t); // 使用缓出插值
    else
        t = t * t; // 使用缓入插值

    ImVec4 color_bg_from = current_state ? colors[ImGuiCol_ButtonActive] : colors[ImGuiCol_Button];
    ImVec4 color_bg_to = current_state ? colors[ImGuiCol_ButtonHovered] : colors[ImGuiCol_Button];
    ImVec4 color_bg = ImVec4(
        ImLerp(color_bg_from.x + 0.15f, color_bg_to.x + 0.15f, t),
        ImLerp(color_bg_from.y + 0.15f, color_bg_to.y + 0.15f, t),
        ImLerp(color_bg_from.z + 0.15f, color_bg_to.z + 0.15f, t),
        ImLerp(color_bg_from.w - 0.15f, color_bg_to.w - 0.15f, t)
    );

    ImVec4 color_square_from = current_state ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : colors[ImGuiCol_SliderGrab];
    ImVec4 color_square_to = current_state ? colors[ImGuiCol_SliderGrab] : ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    ImVec4 color_square = ImVec4(
        ImLerp(color_square_from.x, color_square_to.x, t),
        ImLerp(color_square_from.y, color_square_to.y, t),
        ImLerp(color_square_from.z, color_square_to.z, t),
        ImLerp(color_square_from.w, color_square_to.w, t)
    );

    float square_x = pos.x + (width * 0.15f) + t * (width * 0.69f); // 计算正方形位置
    if (!current_state) {
        square_x = pos.x + (width * 0.85f) - t * (width * 0.69f); // 反向动画
    }

    if (height >= label_size.y) {
        float fg = (height - label_size.y) / 2;
        RenderText(ImVec2(pos.x + (width * 1.15f), pos.y + fg), str_id);
    }

    // 绘制背景矩形
    draw_list->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + height), GetColorU32(color_bg), height * 0.10f);

	
	//draw_list->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + height), GetColorU32(color_bg), height * 0.80f);
	
    //draw_list->AddCircleFilled(ImVec2(circle_x, pos.y + height * 0.50f), height * 0.435f, GetColorU32(color_circle));

	
	
    // 绘制正方形
    float square_size = height * 0.70f; // 正方形的大小
    draw_list->AddRectFilled(ImVec2(square_x, pos.y + (height - square_size) * 0.5f), ImVec2(square_x + square_size, pos.y + (height + square_size) * 0.5f), GetColorU32(color_square));

    return *v;
}
*/

bool ImGui::M_SwitchButton(const char* str_id, bool* v, const ImVec2& size) {
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(str_id);
    ImVec4* colors = GetStyle().Colors;
    ImVec2 pos = window->DC.CursorPos;
    ImDrawList* draw_list = GetWindowDrawList();

    const float gui_height = GetFrameHeight();
    const ImVec2 label_size = CalcTextSize(str_id, NULL, true);
    float width = gui_height * size.x;
    float height = gui_height * size.y;
    const ImRect total_bb(pos, ImVec2(pos.x + (width * 1.15f) + (label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f), pos.y + label_size.y + style.FramePadding.y * 2.0f));
    ItemSize(total_bb, style.FramePadding.y);
    if (!ItemAdd(total_bb, id))
        return false;

    static std::unordered_map<ImGuiID, float> anim_times;
    static std::unordered_map<ImGuiID, bool> button_states;
    const float anim_speed = 0.45f; // 控制动画速度的常量

    bool hovered, held;
    bool pressed = ButtonBehavior(total_bb, id, &hovered, &held);
    if (pressed) {
        *v = !(*v);
        MarkItemEdited(id);
        anim_times[id] = 0.0f; // 重置动画时间
        button_states[id] = *v; // 更新按钮状态
    }

    // 初始化动画时间和按钮状态
    if (anim_times.find(id) == anim_times.end()) {
        anim_times[id] = 0.0f; // 开始时没有延迟
        button_states[id] = *v;
    }

    anim_times[id] += g.IO.DeltaTime;
    anim_times[id] = ImMin(anim_times[id], anim_speed); // 限制动画时间

    float t = anim_times[id] / anim_speed;
    bool current_state = button_states[id];
    if (current_state)
        t = 1.0f - (1.0f - t) * (1.0f - t); // 使用缓出插值
    else
        t = t * t; // 使用缓入插值

    ImVec4 color_bg_from = current_state ? colors[ImGuiCol_ButtonActive] : colors[ImGuiCol_Button];
    ImVec4 color_bg_to = current_state ? colors[ImGuiCol_ButtonHovered] : colors[ImGuiCol_Button];
    ImVec4 color_bg = ImVec4(
        ImLerp(color_bg_from.x + 0.15f, color_bg_to.x + 0.15f, t),
        ImLerp(color_bg_from.y + 0.15f, color_bg_to.y + 0.15f, t),
        ImLerp(color_bg_from.z + 0.15f, color_bg_to.z + 0.15f, t),
        ImLerp(color_bg_from.w - 0.15f, color_bg_to.w - 0.15f, t)
    );

    ImVec4 color_circle_from = current_state ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : colors[ImGuiCol_SliderGrab];
    ImVec4 color_circle_to = current_state ? colors[ImGuiCol_SliderGrab] : ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    ImVec4 color_circle = ImVec4(
        ImLerp(color_circle_from.x, color_circle_to.x, t),
        ImLerp(color_circle_from.y, color_circle_to.y, t),
        ImLerp(color_circle_from.z, color_circle_to.z, t),
        ImLerp(color_circle_from.w, color_circle_to.w, t)
    );

    float circle_x = pos.x + (width * 0.15f) + t * (width * 0.69f); // 计算圆形位置
    if (!current_state) {
        circle_x = pos.x + (width * 0.85f) - t * (width * 0.69f); // 反向动画
    }

    if (height >= label_size.y) {
        float fg = (height - label_size.y) / 2;
        RenderText(ImVec2(pos.x + (width * 1.15f), pos.y + fg), str_id);
    }

	
	draw_list->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + height), GetColorU32(color_bg), height * 0.10f);

	
  //  draw_list->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + height), GetColorU32(color_bg), height * 0.80f);
	
    draw_list->AddCircleFilled(ImVec2(circle_x, pos.y + height * 0.50f), height * 0.435f, GetColorU32(color_circle));

    return *v;
}




bool ImGui::ButtonTextColored(const ImVec4& col, const char* fmt, ...) {
    va_list args;
    va_start(args, fmt);
    TextColoredV(col, fmt, args);
    va_end(args);
    return IsItemClicked();
}

bool ImGui::M_shut(const char* text) {
    const float w = GetWindowWidth() - 20;
    const ImVec2 text_size = CalcTextSize(text, NULL, true);
    SetCursorPosX(w - (text_size.x + GetFrameHeight()/4));
    if (SmallButton(text))
        return true;
    else 
        return false;
}

void ImGui::M_shut(const char* text, bool* close) {
    const float w = GetWindowWidth();
    const ImVec2 text_size = CalcTextSize(text, NULL, true);
    SetCursorPosX(w - (text_size.x + GetFrameHeight()/4));
    if (SmallButton(text))
       *close = true;
}

void ImGui::M_shut_G(const char* text, bool* close, const ImVec4& col) {
    const float w = GetWindowWidth();
    const ImVec2 text_size = CalcTextSize(text, NULL, true);
    SetCursorPosX(w - (text_size.x + GetFrameHeight()/4));
    if (ButtonTextColored(col, text)) {
       *close = !*close;
    }
}

void ImGui::RenderVerticalMenu(const std::vector<std::string>& menu_items, int& selected_index)
{
    const float slider_width = 20.0f;
    const float slider_height = 400.0f;
    const float item_height = slider_height / menu_items.size();

    ImVec4 slider_bg_color = GetStyleColorVec4(ImGuiCol_FrameBg);
    ImVec4 slider_color = GetStyleColorVec4(ImGuiCol_SliderGrab);
    ImVec4 button_color = GetStyleColorVec4(ImGuiCol_Button);
    ImVec4 button_hovered_color = GetStyleColorVec4(ImGuiCol_ButtonHovered);
    ImVec4 button_active_color = GetStyleColorVec4(ImGuiCol_ButtonActive);
    ImVec4 text_color = GetStyleColorVec4(ImGuiCol_Text);

    float target_position = selected_index * item_height;
    static float current_position = 0.0f;
    static float animation_progress = 0.0f;
    static bool animating = false;

    if (animating)
    {
        animation_progress += GetIO().DeltaTime * 5.0f; // 动画速度
        if (animation_progress >= 1.0f)
        {
            animation_progress = 1.0f;
            animating = false;
        }
    }
    current_position = (1.0f - animation_progress) * current_position + animation_progress * target_position;

    BeginGroup();

    InvisibleButton("##slider_bg", ImVec2(slider_width, slider_height));
    ImDrawList* draw_list = GetWindowDrawList();
    ImVec2 slider_min = GetItemRectMin();
    ImVec2 slider_max = GetItemRectMax();
    draw_list->AddRectFilled(slider_min, slider_max, ColorConvertFloat4ToU32(slider_bg_color));

    ImVec2 slider_pos_min = ImVec2(slider_min.x, slider_min.y + current_position);
    ImVec2 slider_pos_max = ImVec2(slider_max.x, slider_min.y + current_position + item_height);
    draw_list->AddRectFilled(slider_pos_min, slider_pos_max, ColorConvertFloat4ToU32(slider_color));

    for (int i = 0; i < menu_items.size(); i++)
    {
        SetCursorScreenPos(ImVec2(slider_max.x + 10, slider_min.y + i * item_height));

        PushStyleColor(ImGuiCol_Button, button_color);
        PushStyleColor(ImGuiCol_ButtonHovered, button_hovered_color);
        PushStyleColor(ImGuiCol_ButtonActive, button_active_color);
        PushStyleColor(ImGuiCol_Text, text_color);

        if (Button(menu_items[i].c_str(), ImVec2(150, item_height - 5)))
        {
            selected_index = i;
            animation_progress = 0.0f;
            animating = true;
        }

        PopStyleColor(4);
    }

    EndGroup();
}
